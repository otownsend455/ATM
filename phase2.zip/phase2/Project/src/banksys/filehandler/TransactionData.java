package banksys.filehandler;

import banksys.system_managers.DateManager;
import banksys.exceptions.DateCreationException;

/**
 * one specific data type to be the input of filehandler operator.
 * extends from data.
 */
public class TransactionData extends Data{
    private String fromId, toId;
    private double amount;
    private DateManager date;
    private String information;

    public TransactionData(String fromId, String toId, double amount, DateManager date, String extraMessage){
        super();
        this.fromId = fromId;
        this.toId = toId;
        this.amount = amount;
        this.date = date;
        this.information = extraMessage;
    }

    public TransactionData(String dataId, String fromId, String toId, double amount, DateManager date,
                           String extraMessage){
        super(dataId);
        this.fromId = fromId;
        this.toId = toId;
        this.amount = amount;
        this.date = date;
        this.information = extraMessage;
    }

    public double getAmount() {
        return amount;
    }

    public String getFromId() {
        return fromId;
    }

    public String getToId() {
        return toId;
    }

    public DateManager getDate() {
        return date;
    }

    public String getExtraMessage(){
        return this.information;
    }

    @Override
    public String toString(){
        return  this.getDataId() + "," +
                fromId + "," +
                toId + "," +
                String.valueOf(this.amount) + "," +
                this.date.toString() + "," + this.information;
    }

    @Override
    public String[] toStringList() {
        return new String[]{this.getDataId(),
                this.fromId,
                this.toId,
                Double.toString(amount),
                date.toString(),
                this.information};
    }

    static TransactionData parse(String[] data){
        try {
            if (data.length == 6) {
                return new TransactionData(data[0],
                        data[1],
                        data[2],
                        Double.valueOf(data[3]),
                        DateManager.parseDate(data[4]),
                        data[5]);
            }else if (data.length == 5){
                return new TransactionData(data[0],
                        data[1],
                        Double.valueOf(data[2]),
                        DateManager.parseDate(data[3]),
                        data[4]);
            }

        } catch (DateCreationException e) {
            e.printStackTrace();
        }
        return null;
    }
}
