package banksys.filehandler;

import java.io.*;

/**
 * special filehandler operators handles transcript files. Take in Transcript filehandler operator.
 * Extends from filehandler operator.
 */
public class TransactionFileOperator extends FileOperator<TransactionData> {

    public TransactionFileOperator(File f){
        super(f);
    }

    @Override
    public void writeData(TransactionData data){
        TransactionData td = data;
        this.insertDataLine(td, 0);
    }

    @Override
    public void insertDataLine(Data data, int lineNum){
        this.loadAllData();
        this.dataSet.add(lineNum, (TransactionData) data);
        String[] allData = new String[this.dataSetLength()];
        for (int i = 0; i < dataSetLength(); i++){
            allData[i] = this.dataSet.get(i).toString();
        }
        this.writeLines(allData, false);
    }

    public void loadMostRecentData(){
        this.dataSet.clear();
        try {
            this.br = new BufferedReader(new FileReader(this.f));
            this.addData(this.br.readLine().split(","));
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (this.br != null) {
                try {
                    this.br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    @Override
    void addData(String[] data){
        TransactionData td = TransactionData.parse(data);
        if (td != null){
            this.dataSet.add(td);
        }
    }
}
