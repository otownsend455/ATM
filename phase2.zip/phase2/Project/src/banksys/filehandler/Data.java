package banksys.filehandler;

import java.util.UUID;

/**
 * abstract class for other data
 * contains a special uuid and makes it unique.
 * contains a toStringList makes it to a readable string list
 */
public abstract class Data {
    final private String dataId;

    Data(){
        this.dataId = UUID.randomUUID().toString();
    }

    Data(String Id){
        this.dataId = Id;
    }

    public String getDataId() {
        return dataId;
    }

    abstract String[] toStringList();
}
