package banksys.filehandler;

public enum TransactionStatus {

}
