package banksys.currency;

/**
 * actually not a formal json parser, just for certain return type of currency json.
 * Analysis the certain type of currency and return the currency rate to EUR
 */
public class CurrencyJsonParser {
    private String json;
    private final int rateIndex;

    public CurrencyJsonParser(String json){
        this.json = json;
        this.rateIndex = json.indexOf("\"rates\":");
    }

    /**
     * return a double that is a ratio to the EUR
     * @param currencyType the type included in CurrencyType class is allowed
     * @return return the ratio of chosen currency type and EUR.
     */
    public Double getCurrency(CurrencyType currencyType){
        int cur = json.indexOf(currencyType.toString(), rateIndex);
        return Double.valueOf(json.substring(json.indexOf(":", cur) + 1, json.indexOf(",", cur)));
    }

}
