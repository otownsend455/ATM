package banksys.currency;

/**
 * currency type including 4 types of currencies
 */
public enum CurrencyType {
    CAD("CAD"),
    CNY("CNY"),
    USD("USD"),
    EUR("EUR"),
    ;

    private String type;

    CurrencyType(String type){
        this.type = type;
    }

    @Override
    public String toString() {
        return this.type;
    }
}
