package banksys.currency;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import static sun.net.www.protocol.http.HttpURLConnection.userAgent;

/**
 *
 * An api handler for fixer api. we get certain json data from varying url.
 * Here is building the HTTP connections between target url and extract data.
 * For those timeout variables, Not local because is can be probably used in the future updates.
 */
class APIHandler {
    private HttpURLConnection conn;
    final private int DEF_CONN_TIMEOUT = 30000;
    final private int DEF_READ_TIMEOUT = 30000;

    /**
     * getting data from api url.
     * Precondition: URL is handled in correct format
     * @param strUrl the URL put in
     * @return JSON data for currencies
     * @throws IOException Connection problems,
     */
    String getJsonFromUrl(String strUrl) throws IOException {
        BufferedReader reader = null;
        String rs = null;
        try {
            StringBuilder sb = new StringBuilder();
            conn = (HttpURLConnection) new URL(strUrl).openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("User-agent", userAgent);
            conn.setUseCaches(false);
            conn.setConnectTimeout(DEF_CONN_TIMEOUT);
            conn.setReadTimeout(DEF_READ_TIMEOUT);
            conn.setInstanceFollowRedirects(false);
            conn.connect();
            InputStream is = conn.getInputStream();
            reader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
            String strRead = null;
            while ((strRead = reader.readLine()) != null) {
                sb.append(strRead);
            }
            rs = sb.toString();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (reader != null) {
                reader.close();
            }
            if (conn != null) {
                conn.disconnect();
            }
        }
        return rs;
    }

    /**
     * analysis the json message to a hash map. Analysis those things
     * @param json the json data in string.
     * @return return a hash map including all the currencyValues in the currency type.
     */
    Map getCurrencyValues(String json){
        Map<CurrencyType, Double> currencyValues = new HashMap<>();
        CurrencyJsonParser currencyJsonParser = new CurrencyJsonParser(json);
        for (CurrencyType currencyType : CurrencyType.values()){
            if (!currencyType.equals(CurrencyType.EUR)){
                currencyValues.put(currencyType, currencyJsonParser.getCurrency(currencyType));
            }
        }
        return currencyValues;
    }
}
