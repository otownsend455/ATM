package banksys.currency.update;

import banksys.currency.CurrencyOperator;
import banksys.currency.CurrencyType;
import banksys.filehandler.CurrencyData;
import banksys.filehandler.CurrencyFileOperator;

import java.io.File;
import java.util.TimerTask;

public class CurrencyUpdateTask extends TimerTask {
    public long TASK_PERIOD;

    /**
     * we can initialize period with more variety if we purchase the plan. this constructor just for cases.
     */
    public CurrencyUpdateTask(){
        this.TASK_PERIOD = 1000*60*60;
    }

    @Override
    public void run() {
        CurrencyOperator currencyOperator = new CurrencyOperator(CurrencyOperator.EndPoint.LATEST);
        CurrencyFileOperator currencyFileOperator = new CurrencyFileOperator(new File(CurrencyFileOperator.FILE_PATH));
        currencyFileOperator.clearFile();
        for (CurrencyType currencyType1 : CurrencyType.values()){
            for (CurrencyType currencyType2 : CurrencyType.values()){
                currencyFileOperator.writeData(new CurrencyData(currencyType1,
                        currencyType2,
                        currencyOperator.getCurrency(currencyType1, currencyType2)));
            }
        }
    }
}
