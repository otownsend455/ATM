To use our program please follow these steps:
1. Mark the phase2 folder as the sources root.
2. Go to File -> Project Structure --> Project SDK. Select 1.8.
3. First sign in as the default bank manager. The username is "username" and the password is "password".
4. You will be presented with a bunch of options as a bank manager. To choose one, enter the number that appears before it in the pop-up menu.
5. Creating a new user will require a user name, and will automatically set the password to the username.
6. If you wish to exit the program as the Bank Manager, but still keep the users and accounts, use option 4 to exit.
7. The date comes preset, but if you want to change it, there is an option in the bank manager menu.
8. Anywhere where it asks for an account number, it means the specific 8 digit account number that is unique to your specific account
9. In order to create a new account for a user, you have to request one in the user screen, then go to the manager screen, hit the create
	account option, and then type yes, for all accounts you requested.
10. the account types must be one of the following, exactly String as follows: "chequing account", "line of credit account", "credit card account",
	or "savings account"


## STARTING THE PROGRAM

The program starts as though this is a brand new ATM. This means that there exists bank workers, but no clients.

When logging in as the bank manager, the username is “username” and the password is “password”.

In accordance to phase 1 specifications, the bank manager will set the date once at the start of the program.
The bank manager has the option to do this within the main menu of the bank manager’s account.
When the bank manager sets the date, the bank manager must select the option in the main menu to “Turn off the ATM”
in order for the date to officially be set.

If a person (let’s call this person “Bob”) wants to join our ATM as a client, then our ATM is under the assumption
that the bank workers have already spoken in-person with Bob and agreed upon a username (let’s say the username is “bob422”)
and account-type (e.g. line of credit, savings, chequing, etc) to be opened within Bob’s soon-to-be-created client account.
Now, it is up to the bank manager to officially create a client account for Bob where that agreed upon username (that is “bob422”)
and account-type. After this has been set, Bob can now log into his account with the username “bob422” and password “bob422”.
Upon entering his account, he can select any of the options in the main menu displayed. If Bob wants to reset his password,
which he may desires to do so for security purposes, then he can select the “set password” option that is within the main menu.
