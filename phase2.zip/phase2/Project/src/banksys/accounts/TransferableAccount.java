package banksys.accounts;

import banksys.system_managers.DateManager;
import banksys.currency.CurrencyType;

public interface TransferableAccount extends Account {
    void transferIn(double amount, String description);
    CurrencyType getCurrency();
    void transferOut(double amount, String description);
    boolean validTransferOut(double amount);
    // for testing
    DateManager getCurrentDate();
}
