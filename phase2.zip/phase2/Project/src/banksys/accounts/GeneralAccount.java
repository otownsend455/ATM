package banksys.accounts;

import banksys.system_managers.DateManager;
import banksys.currency.CurrencyType;
import banksys.filehandler.FileCreator;
import banksys.filehandler.TransactionData;
import banksys.filehandler.TransactionFileOperator;
import java.io.File;
import java.io.Serializable;

/**
 * Abstraction of a product, asset, and debt account.
 */
public abstract class GeneralAccount implements Account, Serializable {

    // PRIVATE-PACKAGE FIELDS
    double balance;
    DateManager creationDate;
    int accountNum;
    final String transactionPath;
    DateManager currentDate;
    boolean exist = true;
    AccountType accountType;
    CurrencyType currencyType;

    public GeneralAccount(int accountNum, DateManager currDate) {
        this.balance = 0.00;
        this.creationDate = currDate;
        this.currentDate = currDate;
        this.accountNum = accountNum;
        this.currencyType = CurrencyType.CAD;
        this.transactionPath = "phase2"
                + File.separator + "Project"
                + File.separator + "src"
                + File.separator + "banksys"
                + File.separator + "transaction"
                + File.separator + accountNum
                + "_" + "transaction.txt";
        this.createTransactionFile();
    }

    public GeneralAccount(int accountNum, DateManager currDate, CurrencyType preferredCurrency) {
        this.balance = 0.00;
        this.creationDate = currDate;
        this.currentDate = currDate;
        this.accountNum = accountNum;
        this.currencyType = preferredCurrency;
        this.transactionPath = "phase2"
                + File.separator + "Project"
                + File.separator + "src"
                + File.separator + "banksys"
                + File.separator + "transaction"
                + File.separator + accountNum
                + "_" + "transaction.txt";
        this.createTransactionFile();
    }

    /**
     * @return the current balance
     */
    public double getBalance() {
        return this.balance;
    }

    /**
     * @return unique account number associated with this account.
     */
    public int getAccountNum() {
        return this.accountNum;
    }

    public CurrencyType getCurrencyType() {
        return currencyType;
    }

    /**
     * Update this current date, currentDate, with the new current date, newCurrDate.
     * @param newCurrDate the new current date.
     */
    public void update(DateManager newCurrDate) {
        this.currentDate = newCurrDate;
    }

    /**
     * Create filehandler which will store transaction for this account.
     */
    private void createTransactionFile() {
        FileCreator fc = new FileCreator(this.transactionPath);
        fc.createFile();
    }

    /**
     * Add a new transaction to this account.
     * @param information FILL IN.
     * @param amount how much money was moved during the transaction.
     * @param target FILL IN
     */
    public void addTransaction(String information, double amount, String target) {

        TransactionData td = new TransactionData(Integer.toString(accountNum), target, amount, this.currentDate, information);
        TransactionFileOperator tfo = new TransactionFileOperator(new File(this.transactionPath));
        tfo.writeData(td);
    }

    /**
     * @return creation date of this account.
     */
    public DateManager getCreationDate() {
        return this.creationDate;
    }


    public void removeAccount() {
        this.exist = false;
    }

    public String getTransaction(int start, int end) {
        TransactionFileOperator tfo = new TransactionFileOperator(new File(this.transactionPath));
        tfo.loadTargetLineOfData(start, end);
        String transactionString = "";
        for (int i = 0; i <= end - start; i++) {
            transactionString += tfo.loadData(i).toString() + "\n";
        }
        return transactionString;
    }

    public AccountType getAccountType() {return this.accountType;}

    public DateManager getCurrentDate() {
        return this.currentDate;
    }

    @Override
    public String toString(){
        return String.valueOf(this.accountNum);
    }

    public boolean isExist() {
        return this.exist;
    }
}
