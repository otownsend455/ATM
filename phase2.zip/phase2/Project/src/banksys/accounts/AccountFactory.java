package banksys.accounts;
import banksys.system_managers.DateManager;
import banksys.currency.CurrencyType;
import banksys.exceptions.NoSuchAccountTypeException;

import java.io.Serializable;

/**
 * Creates different account types; an "account factory".
 */
public class AccountFactory implements Serializable {

    /**
     * @param accountType
     * @param accountNum accountNum for new account.
     * @param currDate current date when account is created.
     * @return an instance of type accountType.
     */
    // NOTE: exception does not need to be thrown here since BankMachineUserControl already checks if the account type is valid

    // NOTE: exception does not need to be thrown here since BankClientViewControl already checks if the account type is valid
    public TransferableAccount getAccount(String accountType, int accountNum, DateManager currDate) throws NoSuchAccountTypeException {
        if (accountType.equals("chequing account")){
            return new ChequingAccount(accountNum, currDate);
        }
        else if (accountType.equals("credit card account")){
            return new CreditCardAccount(accountNum, currDate);
        }
        else if (accountType.equals("line of credit account")){
            return new LineOfCreditAccount(accountNum, currDate);
        }
        else if (accountType.equals("savings account")) {
            return new SavingsAccount(accountNum, currDate);

        }
        else if (accountType.equals("joint chequing account")) {
            return new JointChequingAccount(accountNum, currDate);
        } else throw new NoSuchAccountTypeException();

    }

    public TransferableAccount getAccount(String accountType, int accountNum, DateManager currDate, CurrencyType preferredCurrency) {
        if (accountType.equals("chequing account")){
            return new ChequingAccount(accountNum, currDate, preferredCurrency);
        }
        else if (accountType.equals("credit card account")){
            return new CreditCardAccount(accountNum, currDate, preferredCurrency);
        }
        else if (accountType.equals("line of credit account")){
            return new LineOfCreditAccount(accountNum, currDate, preferredCurrency);
        }

        return new SavingsAccount(accountNum, currDate, preferredCurrency);
    }

    /**
     * @param accountType
     * @param accountNum accountNum for new account.
     * @param currDate creation date of new account.
     * @return an instance of type accountType.
     */
    // NOTE: exception does not need to be thrown here since BankClientViewControl already checks if the account type is valid
    public ProductAccount getProductAccount(String accountType, int accountNum, double amount, int duration,
                                     double monthlyRate, DateManager currDate, CurrencyType preferredCurrency) {
        if (accountType.equals("mortgage account")){
            return new MortgageAccount(accountNum, amount, duration * 12, monthlyRate, currDate, preferredCurrency);
        }
        else {
            return new GICAccount(accountNum, amount, duration, monthlyRate, currDate, preferredCurrency);
        }

    }
}
