package banksys.accounts;

import banksys.system_managers.DateManager;
import banksys.currency.CurrencyType;

import java.io.Serializable;

/**
 * An abstraction of a MortgageAccount and GICAccount.
 */
public abstract class ProductAccount extends GeneralAccount implements Serializable {
    double annualRate;
    int duration;

    ProductAccount(int accountNum, double amount, int duration, double annualRate, DateManager currDate) {
        super(accountNum, currDate);
        this.balance = amount;
        this.duration = duration;
        this.annualRate = annualRate;
    }

    public ProductAccount(int accountNum, double amount, int duration, double monthlyRate, DateManager currDate,
                   CurrencyType preferredCurrency) {
        super(accountNum, currDate, preferredCurrency);
        this.balance = amount;
        this.duration = duration;
        this.annualRate = monthlyRate;
    }

    public int getDuration() {
        return duration;
    }


    public double getAnnualRate() {
        return annualRate;
    }

}
