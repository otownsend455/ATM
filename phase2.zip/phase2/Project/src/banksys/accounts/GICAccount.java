package banksys.accounts;

import banksys.system_managers.DateManager;
import banksys.currency.CurrencyType;

import java.io.Serializable;

/**
 * Represents a guarantee investment certificate account.
 */
public class GICAccount extends ProductAccount implements Serializable {


    public GICAccount(int accountNum, double amount, int duration, double monthlyRate, DateManager currDate,
                      CurrencyType preferredCurrency) {
        super(accountNum, amount, duration, monthlyRate, currDate, preferredCurrency);
        balance = amount;
        this.accountType =  AccountType.GIC_ACCOUNT;
    }

    @Override
    public void update(DateManager newCurrDate) {
        this.currentDate = newCurrDate;
        if (this.currentDate.getDay() == getCreationDate().getDay() &&
                this.currentDate.getMonth() == getCreationDate().getMonth()) {
            this.balance *= (1 + this.annualRate);
        }
    }

    public double returnMoney() {
        if (this.currentDate.getYear() == getCreationDate().getYear() + duration &&
                this.currentDate.getDay() == getCreationDate().getDay() &&
                this.currentDate.getMonth() == getCreationDate().getMonth()) {
            double temp_balance = balance;
            balance = 0;
            removeAccount();
            return temp_balance;
        }
        return 0;
    }

    @Override
    public String toString() {
        return "GIC #" + this.accountNum;
    }



}
