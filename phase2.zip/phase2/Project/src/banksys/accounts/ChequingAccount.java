package banksys.accounts;

import banksys.system_managers.DateManager;
import banksys.currency.CurrencyType;

/**
 * Represents a chequing account.
 */
public class ChequingAccount extends AssetAccount {
    private boolean isPrimary;

    public ChequingAccount (int accountNum, DateManager currDate) {
        super(accountNum, currDate);
        setOverdraftLimit(100); // NOTE: this is a positive value. Look up the definition online.
        this.accountType = AccountType.CHEQUING_ACCOUNT;
        this.isPrimary = false;
    }

    public ChequingAccount (int accountNum, DateManager currDate, CurrencyType preferredCurrency) {
        super(accountNum, currDate, preferredCurrency);
        setOverdraftLimit(100);
        this.accountType = AccountType.CHEQUING_ACCOUNT;
        this.isPrimary = false;
    }

    public boolean isPrimary(){
        return this.isPrimary;
    }

    public void setPrimaryStatus(boolean primaryStatus){
        isPrimary = primaryStatus;
    }


    @Override
    public CurrencyType getCurrency() {
        return this.currencyType;
    }

    @Override
    public String toString() {
        return "Chequing #" + this.accountNum;
    }
}
