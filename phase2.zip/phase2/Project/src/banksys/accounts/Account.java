package banksys.accounts;

import banksys.system_managers.DateManager;

/**
 * Interface of account.
 */
public interface Account {

    double getBalance();
    void update(DateManager date);
    // void createTransactionFile(); removed
    void addTransaction(String information, double amount, String target);
    int getAccountNum();
    AccountType getAccountType();
    DateManager getCreationDate();
    String getTransaction(int start, int end);
}
