package banksys.accounts;

import banksys.system_managers.DateManager;
import banksys.currency.CurrencyType;

import java.io.Serializable;

/**
 * Represents a mortgage account.
 */
public class MortgageAccount extends ProductAccount {

    private double nextPayment;

    public MortgageAccount(int accountNum, double amount, int duration, double annualRate, DateManager currDate,
                           CurrencyType preferredCurrency) {
        super(accountNum, amount, duration, annualRate, currDate, preferredCurrency);
        this.accountType = AccountType.MORTGAGE_ACCOUNT;
        setNextPayment();
    }

    @Override
    public void update(DateManager newCurrDate) {
        this.currentDate = newCurrDate;
        if (isPaymentDate()) {
            this.duration -= 1;
            setNextPayment();
        }
        if (this.balance == 0) {removeAccount();}
    }

    public void payMortgage() {
        this.balance -= this.nextPayment;
    }

    public void setNextPayment() {
        this.nextPayment = this.balance * ((this.annualRate / 12) / (1 - Math.pow((1 + this.annualRate / 12), this.duration)));
    }

    public double getNextPayment() {
        return -this.nextPayment;
    }

    public boolean isPaymentDate() {
        if (this.currentDate.getDay() == getCreationDate().getDay()) {
            return true;
        }
        return false;
    }

    @Override
    public String toString() {
        return "Mortgage #" + this.accountNum;
    }


}
