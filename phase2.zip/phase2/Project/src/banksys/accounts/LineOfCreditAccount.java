package banksys.accounts;

import banksys.system_managers.DateManager;
import banksys.currency.CurrencyType;

/**
 * Represents a line of credit account.
 */
public class LineOfCreditAccount extends DebtAccount {

    LineOfCreditAccount(int accountNum, DateManager currDate) {
        super(accountNum, currDate);
        setCreditLimit(1000);
        this.accountType = AccountType.LINE_OF_CREDIT_ACCOUNT;
    }

    LineOfCreditAccount(int accountNum, DateManager currDate, CurrencyType preferredCurrency) {
        super(accountNum, currDate, preferredCurrency);
        setCreditLimit(1000);
        this.accountType = AccountType.LINE_OF_CREDIT_ACCOUNT;
    }

    @Override
    public CurrencyType getCurrency() {
        return this.currencyType;
    }

    @Override
    public String toString() {
        return "Line Of Credit #" + this.accountNum;
    }

    @Override
    public boolean validTransferOut(double amount) {
        return balance + amount <= creditLimit;
    }
}
