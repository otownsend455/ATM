package banksys.system_managers;

import javax.swing.*;
import java.io.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class MoneyManager implements Serializable {
    private static Map<String, Integer> bills;
    public boolean withdrawFailed;

    public MoneyManager(){
        bills = new HashMap<>(4);
        this.withdrawFailed = false;
    }

    /**
     * Check the number of bills in the machine.
     */
    public void checkBills() {
        for (Map.Entry<String, Integer> entry : bills.entrySet()){
            if (entry.getValue() < 20) {
                try {
                    FileWriter fWriter = new FileWriter("phase2/Project/src/banksys/txtfile/alerts.txt",
                            true);
                    BufferedWriter bWriter = new BufferedWriter(fWriter);
                    String alertText = "The bank machine is low on " + entry.getKey() + " dollar bills.\n";
                    bWriter.write(alertText);
                    bWriter.close();
                    fWriter.close();
                } catch(IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * Add bills to the machine.
     * @param billType the type of bill
     * @param amount the number of bills to add
     */
    public void addMoney(String billType, int amount) {
        for (Map.Entry<String, Integer> entry : bills.entrySet()) {
            if (entry.getKey().equals(billType)) {
                entry.setValue(entry.getValue() + amount);
            }
        }
    }

    /**
     * Write the number of bills in the machine to a file.
     */
    public void billsToFile() {
        try {
            FileWriter fWriter = new FileWriter(new File("").getAbsoluteFile() + "/Project/src/banksys/txtfile/bills.txt");
            BufferedWriter bWriter = new BufferedWriter(fWriter);
            for (Map.Entry<String, Integer> entry : bills.entrySet()) {
                bWriter.write(entry.getKey() + "\n");
                bWriter.write(entry.getValue() + "\n");
            }
            bWriter.close();
            fWriter.close();
        } catch(IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Remove bills from the machine.
     * @param amount the amount that is removed.
     */
    public void withdrawBills(int amount) {
        int bills100 = amount / 100;
        int bills50 = (amount % 100) / 50;
        int bills20 = (amount % 100 % 50) / 20;
        int bills10 = (amount % 100 % 50 % 20) / 10;
        int bills5 = (amount % 100 % 50 % 20 % 10) / 5;



        if (bills.get("100") - bills100 >= 0) {
            bills.put("100", bills.get("100") - bills100);
        } else {
            withdrawFailed = true;
            JOptionPane.showMessageDialog(null, "Insufficient $100 bills in the machine.");
        }
        if (bills.get("50") - bills50 >= 0) {
            bills.put("50", bills.get("50") - bills50);
        } else {
            withdrawFailed = true;
            JOptionPane.showMessageDialog(null, "Insufficient $50 bills in the machine.");
        }
        if (bills.get("20") - bills20 >= 0) {
            bills.put("20", bills.get("20") - bills20);
        } else {
            withdrawFailed = true;
            JOptionPane.showMessageDialog(null, "Insufficient $20 bills in the machine.");
        }
        if (bills.get("10") - bills10 >= 0) {
            bills.put("10", bills.get("10") - bills10);
        } else {
            withdrawFailed = true;
            JOptionPane.showMessageDialog(null, "Insufficient $10 bills in the machine.");
        }
        if (bills.get("5") - bills5 >= 0) {
            bills.put("5", bills.get("5") - bills5);
        } else {
            withdrawFailed = true;
            JOptionPane.showMessageDialog(null, "Insufficient $5 bills in the machine.");
        }
    }

    /**
     * Read the bills from the file.
     */
    public void readBillsFromFile() {
        try {
            File f = new File(new File("").getAbsoluteFile() + "/Project/src/banksys/txtfile/bills.txt");
            Scanner scanner = new Scanner(f);
            while (scanner.hasNext()) {
                String billValue = scanner.nextLine();
                Integer billAmount = Integer.parseInt(scanner.nextLine());
                bills.put(billValue, billAmount);
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }


}
