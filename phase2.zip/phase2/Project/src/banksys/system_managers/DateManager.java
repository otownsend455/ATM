package banksys.system_managers;

import banksys.exceptions.DateCreationException;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.*;

public class DateManager extends Observable implements Serializable {
    private int day, month, year;
    private HashMap<String, Observer> observersList;

    /**
     * constructor for our purpose made date class
     * @param startDay the day part of the date, as an int
     * @param startMonth the month part of the date, as an int
     * @param startYear the year part of the date as an int
     */
    public DateManager(int startDay, int startMonth, int startYear){
        day = startDay;
        month = startMonth;
        year = startYear;
    }

    /**
     * method to increment the date, and turn over new months/years
     */
    public void incrementDate(){
        //31 day months
        if ((month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12) &&
                (day == 31)){
            if(month == 12){
                month = 1;
                year++;
            } else {
                month++;
            }
            day = 1;
        //handling for leap years
        } else if ((month == 2) && ((day == 28 && year % 4 != 0) || (day == 29 && year % 4 == 0))) {
            month++;
            day = 1;
        //30 day months
        } else if ((month == 4 || month == 6 || month == 9 || month == 11) && (day == 30)) {
            month++;
            day = 1;
        } else {
            day++;
        }
    }

    /**
     * getter for the day
     * @return the day
     */
    public int getDay(){
        return day;
    }

    /**
     * getter for the month
     * @return the month
     */
    public int getMonth(){
        return month;
    }

    /**
     * getter for the year
     * @return the year
     */
    public int getYear(){
        return year;
    }

    /**
     * toString method for the date class
     * @return a string of the format day/month/year
     */
    @Override
    public String toString(){
        String date = day + "/" + month + "/" + year;
        return date;
    }

    /**
     * parse a string to a date object
     * @param dateStr the string you want to turn into a date
     * @return the fancy new date object
     * @throws DateCreationException if the string you provided wasn't the right format
     */
    public static DateManager parseDate(String dateStr) throws DateCreationException {
        String[] dateSData = dateStr.split("/");
        if (dateSData.length == 3 && dateSData[0].matches("^\\d+$")
                && dateSData[1].matches("^\\d+$")
                && dateSData[2].matches("^\\d+$")) {
            int[] dateData = {Integer.parseInt(dateSData[0]),
                    Integer.parseInt(dateSData[1]),
                    Integer.parseInt(dateSData[2])};
            return new DateManager(dateData[0], dateData[1], dateData[2]);
        } else throw new DateCreationException();
    }

    public void addObserverList(HashMap<String, Observer> observerList) {
        this.observersList = observerList;
    }


    @Override
    public void notifyObservers() {
        for (String key : observersList.keySet()) {
            observersList.get(key).update(this, this);
        }
    }

    public void setToCurrentDate() {
        Calendar calendar = Calendar.getInstance();
        this.day = Integer.parseInt(new SimpleDateFormat("dd").format(calendar.getTime()));
        this.month = Integer.parseInt(new SimpleDateFormat("MM").format(calendar.getTime()));
        this.year = Integer.parseInt(new SimpleDateFormat("yyyy").format(calendar.getTime()));
    }

}
