package banksys.exceptions;

public class PasswordNotMatchException extends Exception{
    public PasswordNotMatchException(){super();}
}
