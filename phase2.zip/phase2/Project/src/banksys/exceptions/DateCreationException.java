package banksys.exceptions;

public class DateCreationException extends Exception{
    public DateCreationException(){
        super();
    }
    public DateCreationException(Throwable cause){
        super(cause);
    }
}
