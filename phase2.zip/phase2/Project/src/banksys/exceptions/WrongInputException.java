package banksys.exceptions;

public class WrongInputException extends Exception {
    public WrongInputException(){
        super();
    }
}
