package banksys.exceptions;

public class NoSuchAccountException extends Exception {
    public NoSuchAccountException(){super();}
}
