package banksys.exceptions;

public class NoTwoAccountsException extends Exception {
    public NoTwoAccountsException() {super();}
}
