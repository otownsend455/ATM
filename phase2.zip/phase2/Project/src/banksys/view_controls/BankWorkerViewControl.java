package banksys.view_controls;

import banksys.accounts.Account;
import banksys.accounts.JointChequingAccount;
import banksys.system_managers.DateManager;
import banksys.accounts.TransferableAccount;
import banksys.bankworkers.*;
import banksys.currency.CurrencyType;
import banksys.system_managers.MoneyManager;
import banksys.system_managers.UserManager;
import jdk.nashorn.internal.scripts.JO;

import javax.swing.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

class BankWorkerViewControl {

    // leave as package-private in order for bank manager control to have access.
    BankWorker bankWorker;
    UserManager userManager;
    DateManager date;
    BankCentralViewControl centralControl;
    private Icon icon;


    // used when instantiating bank manager control.
    BankWorkerViewControl(BankCentralViewControl centralControl, BankWorker worker, UserManager userManager, DateManager date){
        this.centralControl = centralControl;
        this.bankWorker = worker;
        this.userManager = userManager;
        this.date = date;
        this.icon = new ImageIcon(new File("").getAbsoluteFile() + "/Project/src/banksys/coins.png");
    }

    /**
     * Runs the control for the BankWorker.
     */
    void runWorkerControl() {
        String[] choices = {"1. View product and transferable account requests",
                            "2. Restock the machine",
                            "3. Return to main menu"};
        int input = 0;
        String choice;
        while(input != 3) {
            choice = (String)JOptionPane.showInputDialog(null,
                    "Welcome, " + bankWorker.getUsername() + ". ", "Worker menu",
                    JOptionPane.QUESTION_MESSAGE, icon, choices, "Choose One");
            input = Integer.parseInt(choice.replaceAll("[\\D]",""));

            switch (input) {
                case 1:
                    viewControlCreateAccount();
                    break;
                case 2:
                    bankWorker.restockBankMachine();
                    break;
                case 3:
                    JOptionPane.showMessageDialog(null, "Returning to main menu", "ATM", JOptionPane.QUESTION_MESSAGE, icon);
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Sorry, that wasn't an option, please" +
                                " try again", "ATM", JOptionPane.QUESTION_MESSAGE, icon);
                    break;
            }
        }
    }

    /**
     * Access the menu for choosing between request types.
     */
    public void viewControlCreateAccount(){
        String[] choices = {"Show Account Requests", "Show Product Requests"};
        String userInput = (String)JOptionPane.showInputDialog(null,
                "Please select which you would like to do:", "Manager menu",
                JOptionPane.QUESTION_MESSAGE, null, choices, "Choose One");
        userInput = userInput.toLowerCase();
        if(userInput.matches("show account requests")) {
            viewAccountRequests(userManager);
        } else if (userInput.matches("show product requests")) {
            viewProductRequests(userManager);
        }
    }

    /**
     * View the requests for accounts.
     * @param userManager the UserManager
     */
    void viewAccountRequests(UserManager userManager) {
        File f = new File(new File("").getAbsoluteFile() + "/Project/src/banksys/txtfile/requests.txt");
        Scanner scanner;
        try {
            scanner = new Scanner(f);
            while (scanner.hasNext()) {
                String amounts = scanner.nextLine();
                String[] ary = amounts.split(",");
                String[] choices = {"Yes", "No"};
                String accept = (String)JOptionPane.showInputDialog(null,
                        ary[0] + " wants to create " + ary[1] + "\nEnter 'yes' to accept this request or 'no' to deny.", "Manager menu",
                        JOptionPane.QUESTION_MESSAGE, icon, choices, "Choose One");
                accept = accept.toLowerCase();
                if (accept.equals("yes")) {
                    System.out.println(ary[1]);
                    String[] curChoices = {"CAD", "USD", "EURO", "NCNY"};
                    String curChoice = (String)JOptionPane.showInputDialog(null,
                            "Please select the currency type you wish to use for this account.", "Currency",
                            JOptionPane.QUESTION_MESSAGE, icon, curChoices, "Choose One");
                    CurrencyType type;
                    switch (curChoice) {
                        case "CAD":
                            type = CurrencyType.CAD;
                            break;
                        case "USD":
                            type = CurrencyType.USD;
                            break;
                        case "EURO":
                            type = CurrencyType.EUR;
                            break;
                        case "NCNY":
                            type = CurrencyType.CNY;
                            break;
                        default:
                            type = CurrencyType.CAD;
                            break;
                    }
                    TransferableAccount newAcct = bankWorker.createAccount(ary[1], date, type);
                    userManager.getClient(ary[0]).addTransferableAccount(newAcct);
                    if (ary[1].equals("joint chequing account")){
                        if (newAcct instanceof JointChequingAccount){
                            JointChequingAccount jointChequingAccount = (JointChequingAccount) newAcct;
                            jointChequingAccount.addOwner();
                        }
                    }
                    JFrame frame = new JFrame();
                    JOptionPane.showMessageDialog(frame, "Account created");
                }else{
                    JFrame frame = new JFrame();
                    JOptionPane.showMessageDialog(frame, "Account not created");
                }
            }
            PrintWriter writer = new PrintWriter(new File("").getAbsoluteFile() + "/Project/src/banksys/txtfile/requests.txt");
            writer.print("");
            writer.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    /**
     * View the requests for products.
     * @param userManager a UserManager
     */
    private void viewProductRequests(UserManager userManager) {
        File f = new File(new File("").getAbsoluteFile() + "/Project/src/banksys/txtfile/productRequests.txt");
        Scanner scanner;
        try {
            scanner = new Scanner(f);
            while (scanner.hasNext()) {
                String amounts = scanner.nextLine();
                String[] ary = amounts.split(",");
                String[] choices = {"Yes", "No"};
                String accept = (String)JOptionPane.showInputDialog(null, ary[0] + " wants to create " + ary[1] + " with amount " +
                        ary[2] + " for " + ary[3] + " years" + "\nEnter 'yes' to accept this request or 'no' to deny.", "Manager Menu",
                        JOptionPane.QUESTION_MESSAGE, icon, choices, "Choose One");
                accept = accept.toLowerCase();
                if (accept.equals("yes")) {
                    System.out.println(ary[1]);
                    Account newProduct = bankWorker.createProductAccount(ary[1], Double.parseDouble(ary[2]), Integer.parseInt(ary[3]), 0.05, date, CurrencyType.CAD);
                    userManager.getClient(ary[0]).addProductAccount(newProduct);
                }
            }
            PrintWriter writer = new PrintWriter(new File("").getAbsoluteFile() + "/Project/src/banksys/txtfile/productRequests.txt");
            writer.print("");
            writer.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

}
