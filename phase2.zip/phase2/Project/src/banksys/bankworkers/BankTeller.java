package banksys.bankworkers;
import banksys.Client;
import banksys.system_managers.MoneyManager;
import javax.swing.*;

public class BankTeller extends BankWorker {

    public BankTeller(String username, String password, MoneyManager moneyManager) {
        super(username, password, moneyManager);
    }

    public Client createUserAccount(String userName){
        JFrame frame = new JFrame();
        JOptionPane.showMessageDialog(frame,
                "A bank teller cannot create accounts.",
                "Invalid option",
                JOptionPane.WARNING_MESSAGE);
        return null;
    }
}

