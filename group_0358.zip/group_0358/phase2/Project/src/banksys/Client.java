package banksys;

import banksys.accounts.*;
import banksys.currency.CurrencyType;
import banksys.exceptions.NoSuchAccountException;
import banksys.system_managers.DateManager;
import banksys.system_managers.MoneyManager;
import banksys.filehandler.TransactionFileOperator;

import java.lang.reflect.Array;
import java.util.regex.Pattern;
import java.util.regex.Matcher;


import javax.swing.*;
import java.io.*;
import java.util.*;

public class Client implements Serializable, Observer {
    private String username;
    private String password;
    private ChequingAccount primary;
    //should store the actual instance of primary account in order for it
    // not to be dependent on the list size of accounts from changing

    private HashMap<Integer, TransferableAccount> allTransferableAccounts;
    private HashMap<Integer, Account> allProductAccounts;
    private HashMap<Integer, CreditCardAccount> creditCards;
    private HashMap<Integer, LineOfCreditAccount> lineOfCreditCards;
    private HashMap<Integer, ChequingAccount> chequingAccounts;
    private HashMap<Integer, SavingsAccount> savingsAccounts;
    private HashMap<Integer, MortgageAccount> mortgageAccounts;
    private HashMap<Integer, GICAccount> gicAccounts;

    private CurrencyType currencyType;

    private MoneyManager moneyManager;


    public Client(String username, String password, MoneyManager moneyManager) {
        this.username = username;
        this.password = password;
        this.moneyManager = moneyManager;

        this.creditCards = new HashMap<>();
        this.lineOfCreditCards = new HashMap<>();
        this.chequingAccounts = new HashMap<>();
        this.savingsAccounts = new HashMap<>();
        this.allTransferableAccounts =  new HashMap<>();
        this.allProductAccounts = new HashMap<>();
        this.mortgageAccounts = new HashMap<>();
        this.gicAccounts = new HashMap<>();
    }

    /**
     *
     * @return the clients password
     */
    public String getPassword() {
        return this.password;
    }

    /**
     *
     * @param password
     * changes the current password to the parameter password
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     *
     * @return the client's username
     */
    public String getUsername() {
        return this.username;
    }

    /**
     *
     * @return the client's transferable accounts
     */
    public HashMap<Integer, TransferableAccount> getallTransferableAccounts(){
        return this.allTransferableAccounts;
    }

    /**
     *
     * @return the client's product accounts
     */
    public HashMap<Integer, Account> getallProductAccounts(){
        return this.allProductAccounts;
    }

    /**
     *
     * @return the client's chequing accounts.
     */
    public HashMap<Integer, ChequingAccount> getChequingAccounts() {
        return this.chequingAccounts;
    }


    /**
     * Returns an array list representing all the account types of this client that have the ability to transfer out money (digital and physical)
     * This array list would consist of chequing, savings, and line of credit.
     * @return an array list representing all the account types of this client that have the ability to transfer out (digital and physical)
     */
    public ArrayList<TransferableAccount> getTransferOutAccounts(){
        ArrayList<TransferableAccount> chequingArray = new ArrayList<>(this.chequingAccounts.values());
        ArrayList<TransferableAccount> savingsArray = new ArrayList<>(this.savingsAccounts.values());
        ArrayList<TransferableAccount> lineOfCreditArray = new ArrayList<>(this.lineOfCreditCards.values());
        ArrayList<TransferableAccount> allTransferOutAccounts = new ArrayList<>();
        allTransferOutAccounts.addAll(chequingArray);
        allTransferOutAccounts.addAll(savingsArray);
        allTransferOutAccounts.addAll(lineOfCreditArray);
        return allTransferOutAccounts;
    }

    /**
     * @return all transferable accounts as an array (includes credit card even though it does not have the ability to transfer in)
     */
    public ArrayList<TransferableAccount> getallTransferAccounts(){
        return new ArrayList<>(this.allTransferableAccounts.values());
    }

    /**
     *
     * @return the client's primary account's number
     */
    public int getPrimaryAccountNum() {
        return this.primary.getAccountNum();
    }

    /**
     *
     * @return the actual primary account object of the client
     */
    public ChequingAccount getPrimaryAccount() {
        return this.primary;
    }

    /**
     *
     * @return the client's preferred currency type
     */
    public CurrencyType getCurrencyType() {
        return currencyType;
    }

    /**
     * Removes the primary account status of the current primary account
     * and sets newPrimary to have the primary account status.
     * @param newPrimary the new account to have the primary account status.
     */
    public void setPrimary(ChequingAccount newPrimary) {
        if (!(newPrimary.getAccountType() == AccountType.JOINT_CHEQUING_ACCOUNT)) {
            this.primary = newPrimary;
        }
    }

    /**
     *
     * @param accNum the account number of the account you want to access
     * @return the account object with the account number accNum
     */
    TransferableAccount getSpecificAccount(Integer accNum) {
        return allTransferableAccounts.get(accNum);
    }

    /**
     *
     * @return calculates the net total of the clients debt and assets
     */
    public double calculateNetTotal() {
        return calculateTotalAssets() - calculateTotalDebt();
    }

    /**
     *
     * @return the client's total debt
     */
    private double calculateTotalDebt(){
        double totalDebt = 0;

        ArrayList<TransferableAccount> creditCardAccountsCollectionArray = new ArrayList<>(creditCards.values());
        ArrayList<TransferableAccount> lineOfCreditCardArray = new ArrayList<>(lineOfCreditCards.values());
        ArrayList<TransferableAccount> debtAccountsArray = new ArrayList<>();

        debtAccountsArray.addAll(creditCardAccountsCollectionArray);
        debtAccountsArray.addAll(lineOfCreditCardArray);

        for (TransferableAccount currDebtAccount : debtAccountsArray) {
            totalDebt = totalDebt + currDebtAccount.getBalance();
        }

        return totalDebt;
    }

    /**
     *
     * @return the client's total assets
     */
    private double calculateTotalAssets(){
        double totalAsset = 0;

        ArrayList<TransferableAccount> savingsAccountArray = new ArrayList<>(savingsAccounts.values());
        ArrayList<TransferableAccount> chequingAccountArray = new ArrayList<>(chequingAccounts.values());
        ArrayList<TransferableAccount> assetAccountsArray = new ArrayList<>();

        assetAccountsArray.addAll(savingsAccountArray);
        assetAccountsArray.addAll(chequingAccountArray);

        for(TransferableAccount currAssetAccount : assetAccountsArray){
            totalAsset = totalAsset + currAssetAccount.getBalance();
        }

        return totalAsset;
    }

    /**
     *
     * @param account
     * adds account to a client's set of owned accounts
     */
    public void addTransferableAccount(TransferableAccount account) {
        allTransferableAccounts.put(account.getAccountNum(), account);

        if (account.getAccountType() == AccountType.CHEQUING_ACCOUNT){
            chequingAccounts.put(account.getAccountNum(), (ChequingAccount) account);
        }
        else if(account.getAccountType() == AccountType.SAVINGS_ACCOUNT){
            savingsAccounts.put(account.getAccountNum(), (SavingsAccount) account);
        }
        else if(account.getAccountType() == AccountType.CREDIT_CARD_ACCOUNT){
            creditCards.put(account.getAccountNum(), (CreditCardAccount) account);
        }
        else if(account.getAccountType() == AccountType.LINE_OF_CREDIT_ACCOUNT){
            lineOfCreditCards.put(account.getAccountNum(), (LineOfCreditAccount) account);
        }
    }

    /**
     *
     * @param account
     * adds account to the client's set of product accounts
     */
    public void addProductAccount(Account account) {
        allProductAccounts.put(account.getAccountNum(), account);

        if (account.getAccountType() == AccountType.MORTGAGE_ACCOUNT){
            mortgageAccounts.put(account.getAccountNum(), (MortgageAccount) account);
        }
        else if (account.getAccountType() == AccountType.GIC_ACCOUNT){
            gicAccounts.put(account.getAccountNum(), (GICAccount) account);
        }
    }


    /**
     * Represents a PHYSICAL cash withdrawal.
     * @param amount amount to be withdrawn.
     * @param accountWithdrawingFrom account that is being withdrawn from
     */
    public void withdraw(int amount, TransferableAccount accountWithdrawingFrom) {
        moneyManager.withdrawBills(amount);
        if(!moneyManager.withdrawFailed) {
            accountWithdrawingFrom.transferOut(amount, "Withdawal made");
            accountWithdrawingFrom.addTransaction("withdraw", amount, "cash");
            moneyManager.checkBills();
        }
        else{
            JFrame frame = new JFrame();
            JOptionPane.showMessageDialog(frame,"Insufficient funds in the ATM. Please try again tomorrow once the ATM has been restocked. We apologize for the inconvenience.",
                    "Insufficient funds in the ATM", JOptionPane.ERROR_MESSAGE);
        }
    }


    /**
     * Represents deposits of physical cash and cheques.
     * Deposits are sent directly to the primary chequing account.
     * Reads bill denominations from deposits.txt in the order of $5, $10, $20, $50, and $100 bills
     * 2 kinds of deposits:
     *              1. Cheque: Amount being deposited must be on the first line of the text file
     *              Must have single number in the text file. Otherwise the pattern matcher in the
     *              deposit method won’t know what number to match as the amount being deposited.
     *              2. Cash:  Amount being deposited must be on the first line of the text file
     *              Must be formatted as the number of bills being deposited in the order of 5’s,
     *              10’s, 20’s, 50’s, and 100’s dollar bills. E.g. if a line in
     *              deposit.txt had: “5, 3, 1, 0, 100” this would mean to deposit
     *              5 $5’s, 3 $10, 1 $20, 0 $50, 1 $100 - resulting in a total of $160 being deposited.
     * @param depositType "1" represents depositing cash, "2" represents depositing a cheque
     */
    public void deposit(int depositType) {
        String[] splitVal;
        double sum = 0;
        try{
            FileReader fr = new FileReader(new File("").getAbsoluteFile() + "/Project/src/banksys/txtfile/deposits.txt");
            BufferedReader br = new BufferedReader(fr);
            String vals = br.readLine();
            if (depositType == 1){
                if (vals.matches("(\\d)+,(\\d)+,(\\d)+,(\\d)+,(\\d)+")) {
                    splitVal = vals.split(",");
                    sum += 5 * Integer.parseInt(splitVal[0]);
                    sum += 10 * Integer.parseInt(splitVal[1]);
                    sum += 20 * Integer.parseInt(splitVal[2]);
                    sum += 50 * Integer.parseInt(splitVal[3]);
                    sum += 100 * Integer.parseInt(splitVal[4]);
                    this.getPrimaryAccount().transferIn(sum, "Deposit of bills made");
                    this.getPrimaryAccount().addTransaction("deposit", sum, "cash");
                    moneyManager.addMoney("5", Integer.parseInt(splitVal[0]));
                    moneyManager.addMoney("10", Integer.parseInt(splitVal[1]));
                    moneyManager.addMoney("20", Integer.parseInt(splitVal[2]));
                    moneyManager.addMoney("50", Integer.parseInt(splitVal[3]));
                    moneyManager.addMoney("100", Integer.parseInt(splitVal[4]));
                } else {
                    JOptionPane.showMessageDialog(null, "You don't have any cash to deposit.");
                }
            }
            else{
                if(!vals.matches("(\\d)+,(\\d)+,(\\d)+,(\\d)+,(\\d)+")) {
                    Pattern p = Pattern.compile("\\d+.?[\\d]*");
                    Matcher m = p.matcher(vals);
                    while (m.find()) {
                        sum = Double.parseDouble(m.group());
                        this.getPrimaryAccount().transferIn(sum, "Deposit of cheque made");
                        this.getPrimaryAccount().addTransaction("deposit", sum, "cheque");
                        System.out.println("transaction complete");
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "You don't have any cheques to deposit.");
                }
            }

        } catch(IOException e){
            System.out.println("Error: " + e);
        }
    }

    /**
     *
     * @param type type of requested account type
     * sends a request for the bank manager to read that the client wants a new account of account type type
     */
    public void requestNewAccount(AccountType type) {
        try {
            String request = this.getUsername() + "," + type.toString() + "\n"; // toString version of account type is added to file.
            FileWriter fr = new FileWriter(new File("").getAbsoluteFile() + "/Project/src/banksys/txtfile/requests.txt", true);
            fr.write(request);
            fr.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     *
     * @param type type of product account
     * @param amount amount of money for the product account
     * @param years amount of years for the product account
     * sends a request for the bank manager to read that the client wants a new product account of account type type
     * for an amount amount for years years
     */
    public void requestNewProduct(AccountType type, double amount, int years) {
        try {
            String request = this.getUsername() + "," + type.toString() + "," + amount + "," + years + "\n"; // toString version of account type is added to file.
            FileWriter fr = new FileWriter(new File("").getAbsoluteFile() + "/Project/src/banksys/txtfile/productRequests.txt", true);
            fr.write(request);
            fr.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     *
     * @param accNum the accNun of the account you want to see the recent transactions for
     * @param n the amount of recent transactions you want to see
     * @return n recent transactions of account with account number accNum
     */
    public String getRecentTransactions(int accNum, int n) {
        String num = Integer.toString(accNum);
        File f = new File(new File("").getAbsoluteFile() + "/Project/src/banksys/transaction/" + num + "_transaction.txt");
        StringBuilder s = new StringBuilder();
        if (f.exists()) {
            TransactionFileOperator t = new TransactionFileOperator(f);
            t.loadAllData();
            String ss;
            for(int i = 0; i < n; i++){
                 String[] sss = t.loadData(i).toStringList();
                 ss = sss[sss.length - 1] + " " + sss[3] + " from account " + sss[1] + " to " + sss[2] + " on " + sss[4] + "\n";
                s.append(ss);
            }
            return s.toString();
        } else{
            return ""; // placeholder
        }
    }

    /**
     *
     * @param accNum of the account you want to see the recent transactions of
     * @param n the amount of recent transactions you want to see
     * @return a string listing n recent transactions unformatted
     */
    public String getRecentTransactionsUnformatted(int accNum, int n) {
        String num = Integer.toString(accNum);
        File f = new File(new File("").getAbsoluteFile() + "/Project/src/banksys/transaction/" + num + "_transaction.txt");
        StringBuilder s = new StringBuilder();
        if (f.exists()) {
            TransactionFileOperator t = new TransactionFileOperator(f);
            t.loadAllData();
            String ss;
            for(int i = 0; i < n; i++){
                ss = Arrays.toString(t.loadData(i).toStringList()) + "\n";
                s.append(ss);
            }
            return s.toString();
        } else{
            return ""; // placeholder
        }
    }

    /**
     *
     * @param accNum the account number of the account you want to remove
     *
     */
    public void removeAccount(Integer accNum){
        if(!this.getPrimaryAccount().equals(accNum) && this.getSpecificAccount(accNum).getBalance() == 0){
            allProductAccounts.remove(accNum);
        }
    }

    /**
     *
     * @param o clients observer that passes the dates into the counts
     * @param newDate the new date to pass into the client and its accounts
     */
    @Override
    public void update(Observable o, Object newDate) {
        DateManager date = (DateManager) newDate;
        for (Integer key: mortgageAccounts.keySet()) {
            MortgageAccount ma = mortgageAccounts.get(key);
            ma.update(date);
            if (ma.isPaymentDate()) {
                if (primary.validTransferOut(ma.getNextPayment())) {
                    System.out.println(ma.getNextPayment());
                    primary.transferOut(ma.getNextPayment(), "Pay Mortgage");
                }
            }
            if (! ma.isExist()) {
                allProductAccounts.remove(ma.getAccountNum());
                mortgageAccounts.remove(ma.getAccountNum());
            }
            ma.payMortgage();
        }
        for (Integer key: gicAccounts.keySet()) {
            GICAccount ga = gicAccounts.get(key);
            ga.update(date);
            double money = ga.returnMoney();
            if (money != 0) {
                primary.transferIn(money, "receive money from GIC");
            }
            if (! ga.isExist()) {
                allProductAccounts.remove(ga.getAccountNum());
                gicAccounts.remove(ga.getAccountNum());
            }
        }
        for (Integer key : allTransferableAccounts.keySet()) {
            allTransferableAccounts.get(key).update(date);
        }
    }

}