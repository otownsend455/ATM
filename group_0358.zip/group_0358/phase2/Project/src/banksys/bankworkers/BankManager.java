package banksys.bankworkers;
import banksys.*;
import banksys.accounts.Account;
import banksys.currency.CurrencyType;
import banksys.system_managers.DateManager;
import banksys.system_managers.MoneyManager;

import java.io.*;

/**
 * This is where Bank Managers do their bidding.
 */

public class BankManager extends BankWorker {
    private DateManager date;
    /**
     * constructor for a new bank manager
     *
     * @param username takes a username
     * @param password and a password
     */
    public BankManager(String username, String password, DateManager date, MoneyManager moneyManager) {
        super(username, password, moneyManager);
        this.date = date;
    }

    /**
     * Create a new user
     * @param userName the value of their username, and what their password will be
     * @return a hot off the press client
     */
    public Client createUserAccount(String userName) {
        String regex = "^[a-zA-Z0-9]+([a-zA-Z0-9]*[_-]*)*[a-zA-Z0-9]+(?=.*?[A-Za-z]).+$";
        if (userName.matches(regex)
                && userName.length() > 3) {
            return new Client(userName, userName, moneyManager);
        }
        return null;
    }

}
