package banksys.bankworkers;
import banksys.Client;
import banksys.accounts.Account;
import banksys.accounts.ProductAccount;
import banksys.system_managers.MoneyManager;
import banksys.system_managers.DateManager;
import banksys.accounts.AccountFactory;
import banksys.accounts.TransferableAccount;
import banksys.currency.CurrencyType;

import java.io.*;

public abstract class BankWorker implements Serializable {

    String password;
    String username;
    AccountFactory accountGenerator = new AccountFactory();
    MoneyManager moneyManager;

    public BankWorker(String username, String password, MoneyManager moneyManager){
        this.username = username;
        this.password = password;
        this.moneyManager = moneyManager;
    }

    public abstract Client createUserAccount(String userName);

    /**
     * add bills back to the bank machine, if there are less than 20 of that denomination
     */
    public void restockBankMachine() {
        try {
            FileReader fReader = new FileReader(new File("").getAbsoluteFile() + "/Project/src/banksys/txtfile/alerts.txt");
            BufferedReader bReader = new BufferedReader(fReader);
            while (true) {
                String line = bReader.readLine();
                if (line == null) {
                    break;
                } else {
                    String[] alert = line.split(" ");
                    System.out.println(alert[6]);
                    moneyManager.addMoney(alert[6], 20);
                }
            }
            PrintWriter pw = new PrintWriter(new File("").getAbsoluteFile() + "/Project/src/banksys/txtfile/alerts.txt");
            pw.close();
            bReader.close();
            fReader.close();
        } catch(IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * use the alert.txt filehandler to see what accounts have been requested, then create them
     *
     * @param type         of account being added
     * @param creationDate date the account is being created(current date)
     */
    public TransferableAccount createAccount(String type, DateManager creationDate, CurrencyType preferredCurrency) {
        TransferableAccount a;
        try {
            FileReader fr = new FileReader(new File("").getAbsoluteFile() + "/Project/src/banksys/txtfile/accountNum.txt");
            BufferedReader br = new BufferedReader(fr);
            int accountNumber = Integer.parseInt(br.readLine());
            // NOTE: exception does not need to be thrown here since BankClientViewControl already checks if the account type is valid
            a = accountGenerator.getAccount(type, accountNumber, creationDate, preferredCurrency);
            accountNumber += 1;
            FileWriter fw = new FileWriter(new File("").getAbsoluteFile() + "/Project/src/banksys/txtfile/accountNum.txt");
            BufferedWriter bw = new BufferedWriter(fw);
            bw.write(String.valueOf(accountNumber));
            bw.close();
            fw.close();
            br.close();
            fr.close();
        } catch (IOException e) {
            a = null;
            e.printStackTrace();
        }
        return a;
    }

    /**
     * Create a product account.
     * @param accountType the type of account
     * @param amount the amount
     * @param duration the length of the account
     * @param monthlyRate the amount to pay per month
     * @param creationDate the creation date of the account
     * @param preferredCurrency the preferred currency of the account
     * @return
     */
    public ProductAccount createProductAccount(String accountType, double amount, int duration,
                                 double monthlyRate, DateManager creationDate, CurrencyType preferredCurrency) {
        ProductAccount a;
        try {
            FileReader fr = new FileReader(new File("").getAbsoluteFile() + "/Project/src/banksys/txtfile/accountNum.txt");
            BufferedReader br = new BufferedReader(fr);
            int accountNumber = Integer.parseInt(br.readLine());
            a = accountGenerator.getProductAccount(accountType, accountNumber, amount, duration, monthlyRate, creationDate, preferredCurrency);
            accountNumber += 1;
            FileWriter fw = new FileWriter(new File("").getAbsoluteFile() + "/Project/src/banksys/txtfile/accountNum.txt");
            BufferedWriter bw = new BufferedWriter(fw);
            bw.write(String.valueOf(accountNumber));
            bw.close();
            fw.close();
            br.close();
            fr.close();
        } catch (IOException e) {
            a = null;
            e.printStackTrace();
        }
        return a;
    }

    /**
     * Get the password
     * @return the password
     */
    public String getPassword(){
        return this.password;
    }

    /**
     * Get the username.
     * @return the username
     */
    public String getUsername(){
        return this.username;
    }

    /**
     * Set the password.
     * @param password the new password.
     */
    public void setPassword(String password) {this.password = password;}

}
