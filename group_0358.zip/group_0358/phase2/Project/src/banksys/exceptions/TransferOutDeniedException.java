package banksys.exceptions;

public class TransferOutDeniedException extends Exception {
    public TransferOutDeniedException() {super();}
}
