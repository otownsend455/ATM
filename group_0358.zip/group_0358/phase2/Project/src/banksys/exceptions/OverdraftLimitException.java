package banksys.exceptions;

public class OverdraftLimitException extends Exception {
    public OverdraftLimitException(){super();}
}
