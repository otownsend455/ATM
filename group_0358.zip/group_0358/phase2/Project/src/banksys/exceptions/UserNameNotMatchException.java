package banksys.exceptions;

public class UserNameNotMatchException extends Exception{
    public UserNameNotMatchException(){
        super();
    }
}
