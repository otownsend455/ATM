package banksys.exceptions;

public class NoSuchAccountTypeException extends Exception{
    public NoSuchAccountTypeException(){super();}
}
