package banksys.system_managers;

import banksys.Client;
import banksys.accounts.AccountType;
import banksys.accounts.TransferableAccount;
import banksys.currency.CurrencyType;
import banksys.filehandler.CurrencyFileOperator;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

/**
 * Represents a Transfer Manager. Performs operations of the bank relating to transfers.
 */
public class TransferManager {

    /**
     * Represents a transfer to a non-user (e.g. paying a bill)
     * @param transferFromAcc the account of client where the amount will be transferred from
     * @param amount the amount being transferred
     * @param description description of transaction
     */
    public void transferToNonUser(TransferableAccount transferFromAcc, double amount, String description, String username){
        double amountC = new CurrencyFileOperator(new File(CurrencyFileOperator.FILE_PATH))
                .findCurrency(transferFromAcc.getCurrency(), CurrencyType.CAD);
        transferFromAcc.transferOut(amount, description);

        try{
            FileWriter fw = new FileWriter("phase2/Project/src/banksys/txtfile/outgoing.txt", true);
            fw.append(description).append(" of amount $").append(String.valueOf(amountC * amount)).append(" by ").append(username);
            System.out.println("test");
            fw.close();
        }catch(IOException e){
            System.out.println("Error: " + e);
        }
        transferFromAcc.addTransaction("withdraw", amount, description);
    }

    /**
     * Represents a digital transfer between accounts of a single user.
     * @param transferFromAcc the account of client where the amount will be transferred from
     * @param transferToAcc the account of the client where the amount will be transferred to
     * @param amount the amount being transferred
     */
    public void transferBetweenAccounts(TransferableAccount transferFromAcc, TransferableAccount transferToAcc, double amount, String description) {
        if (!(transferFromAcc.getAccountType() == AccountType.JOINT_CHEQUING_ACCOUNT || transferToAcc.getAccountType() == AccountType.JOINT_CHEQUING_ACCOUNT)) {
            double amountC = new CurrencyFileOperator(new File(CurrencyFileOperator.FILE_PATH))
                    .findCurrency(transferFromAcc.getCurrency(), transferToAcc.getCurrency());
            transferFromAcc.transferOut(amount, description);
            transferToAcc.transferIn(amountC * amount, description);
            transferFromAcc.addTransaction("withdraw", amount, Integer.toString(transferToAcc.getAccountNum()));
            transferToAcc.addTransaction("deposit", amountC * amount, Integer.toString(transferFromAcc.getAccountNum()));
        }
    }

    /**
     * Represents a digital transfer to another user in the bank.
     * Digital money is transferred to clientTransferTo and directly deposited in their chequing account.
     * @param clientTransferTo the client that the money is being transferred to
     * @param clientTransferFrom the client that the money is being transferred from
     * @param amount amount which Client clientTransferFrom is transferring
     */
    public void transferToUser(Client clientTransferTo, Client clientTransferFrom, double amount, String description) {
        double amountC = new CurrencyFileOperator(new File(CurrencyFileOperator.FILE_PATH))
                .findCurrency(clientTransferFrom.getPrimaryAccount().getCurrency(), clientTransferTo.getPrimaryAccount()
                        .getCurrency());
        clientTransferFrom.getPrimaryAccount().transferOut(amount, description);
        clientTransferTo.getPrimaryAccount().transferIn(amountC * amount, description);
        clientTransferFrom.getPrimaryAccount().addTransaction("withdraw", amount, clientTransferTo.getUsername());
        clientTransferTo.getPrimaryAccount().addTransaction("deposit", amountC * amount, clientTransferFrom.getUsername());

    }
}
