package banksys.system_managers;

import banksys.Client;
import banksys.bankworkers.BankWorker;
import banksys.filehandler.SerializableObjectOperator;

import java.io.File;
import java.util.HashMap;

/**
 * Stores and manages soft log data of all users (Bank Worker(s) and Client(s)) of the bank.
 * Soft logs:
 *            - exist during the runtime of the program that allow easy access to existing users.
 *            - represented by a HashMap where key is username and value is a user object.
 * Hard logs:
 *            - these are bankWorkerHardLog.txt, clientHardLog.txt
 *            - exist permanently in memory as txt files.
 */
public class UserManager {

    private HashMap<String, BankWorker> bankWorkerSoftLog;
    private HashMap<String, Client> clientSoftLog;
    private DateManager currDate;


    public UserManager(DateManager currDate){

        this.bankWorkerSoftLog = new HashMap<>();
        this.clientSoftLog = new HashMap<>();
        this.currDate = currDate;
    }

    /**
     * Transfers hard log data of client(s) and bank worker(s) to soft logs.
     */
    /*
    public void updateUserSoftLog(){
        updateClientSoftLog();
        updateBankWorkerLog();
    }
    */

    public void updateUserSoftLog() {
        File client_f = new File("/Users/oliviatownsend/Desktop/group_0358/phase2/Project/src/banksys/txtfile/clientHardLog.txt");
        //File worker_f = new File("phase2/Project/src/banksys/txtfile/bankWorkerHardLog.txt");
        //this.bankWorkerSoftLog = getUsers(worker_f);
        this.clientSoftLog = getUsers(client_f);
    }

    public HashMap getUsers(File f) {
        SerializableObjectOperator so = new SerializableObjectOperator(f);
        so.loadAllData();
        HashMap userSet = new HashMap<>();
        if (so.dataSetLength() > 0) {
            userSet = (HashMap) so.loadData(0).getStoringObject();
        }
        return userSet;
    }

    /**
     * Transfers hard log data of client(s) to soft logs.
     */
    /*
    public void updateClientSoftLog(){
        ArrayList<Client> clients = userReader.getClients(currDate);
        for(int i = 0; i < clients.size(); i++){
            Client client = clients.get(i);
            String clientUsername = client.getUsername();
            this.clientSoftLog.put(clientUsername, client);
        }
    }
    */

    /**
     * Transfers hard log data of bank worker(s) to soft logs.
     */
    /*
    public void updateBankWorkerLog(){
        ArrayList<BankWorker> BankWorker = userReader.getBankWorker();
        for(int i = 0; i < BankWorker.size(); i++){
            BankWorker bankWorker = BankWorker.get(i);
            String bankWorkerUsername = bankWorker.getUsername();
            this.bankWorkerSoftLog.put(bankWorkerUsername, bankWorker);
        }
    }
    */

    /**
     * Returns true if password corresponds to username in bank.
     * @param userType type of user (bank worker or client)
     * @param username username that is assumed by user.
     * @param password password that is assumed by user.
     * @return true if password corresponds to username in bank.
     */
    public boolean isValidPassword(String userType, String username, String password){
        String associatedPassword;

        if (userType.equals("bankworker")){
             BankWorker thisBankWorker = bankWorkerSoftLog.get(username);
             associatedPassword = thisBankWorker.getPassword();
            return associatedPassword.equals(password);
        }

        Client thisClient = clientSoftLog.get(username);
        associatedPassword = thisClient.getPassword();
        return associatedPassword.equals(password);
    }

    /**
     * Returns true if a user associated with username exists.
     * @param userType type of user (bank worker or client)
     * @param username username that is assumed by user.
     * @return true if a user associated with username exists.
     */
    public boolean isValidUsername(String userType, String username){
        if (userType.equals("bankworker")){
            return this.bankWorkerSoftLog.containsKey(username);
        }
        return this.clientSoftLog.containsKey(username);
    }


    /**
     * Returns client from soft log associated with the username username
     * @return client from soft log associated with the username username
     */
    public Client getClient(String username){
        return this.clientSoftLog.get(username);
    }


    /**
     * Returns bank worker from soft log associated with the username username
     * @return bank worker from soft log associated with the username username
     */
    public BankWorker getBankWorker(String username){
        return this.bankWorkerSoftLog.get(username);
    }


    public void addClient(Client client){
        clientSoftLog.put(client.getUsername(), client);
    }

    public void addBankWorker(BankWorker worker) {
        bankWorkerSoftLog.put(worker.getUsername(), worker);
    }

    public HashMap getClientSoftLog(){
        return clientSoftLog;
    }

    public HashMap getbankWorkerSoftLog(){
        return bankWorkerSoftLog;
    }
}
