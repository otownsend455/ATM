package banksys.accounts;

import banksys.system_managers.DateManager;
import banksys.currency.CurrencyType;

/**
 * Represents a debt account.
 */
public abstract class DebtAccount extends GeneralAccount implements TransferableAccount {
    double creditLimit;

    DebtAccount(int accountNum, DateManager currDate) {
        super(accountNum, currDate);
    }

    DebtAccount(int accountNum, DateManager currDate, CurrencyType preferredCurrency) {
        super(accountNum, currDate, preferredCurrency);
    }


    void setCreditLimit(double amount) {
        this.creditLimit = amount;
    }

    public abstract boolean validTransferOut(double amount);

    /**
     * @param amount amount being transferred in
     * @param description description of transaction
     */
    public void transferIn(double amount, String description) {
        this.balance -= amount;
    }


    /**
     * @param amount amount being transferred out
     * @param description description of transaction
     */
    public void transferOut(double amount, String description) {
        this.balance += amount;
    }

    public double getCreditLimit() {
        return this.creditLimit;
    }
}
