package banksys.accounts;

import banksys.system_managers.DateManager;
import banksys.currency.CurrencyType;

/**
 * Represents a savings account.
 */
public class SavingsAccount extends AssetAccount {

    public SavingsAccount(int accountNum, DateManager date) {
        super(accountNum, date);
        this.accountType = AccountType.SAVINGS_ACCOUNT;
        this.setOverdraftLimit(0);
    }

    public SavingsAccount(int accountNum, DateManager date, CurrencyType preferredCurrency) {
        super(accountNum, date, preferredCurrency);
        this.accountType = AccountType.SAVINGS_ACCOUNT;
        this.setOverdraftLimit(0);
    }

    @Override
    public void update(DateManager newCurrDate) {
        this.currentDate = newCurrDate;
        if (getCurrentDate().getDay() == 1) {
            this.balance *= 1.001;
        }
    }

    @Override
    public CurrencyType getCurrency() {
        return this.currencyType;
    }

    @Override
    public String toString() {
        return "Savings #" + this.accountNum;
    }
}
