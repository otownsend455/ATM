package banksys.accounts;

/**
 * Stores and displays all account types existing at the ATM.
 */
public enum AccountType {
    CHEQUING_ACCOUNT("chequing account"),
    CREDIT_CARD_ACCOUNT("credit card account"),
    LINE_OF_CREDIT_ACCOUNT("line of credit account"),
    SAVINGS_ACCOUNT("savings account"),
    MORTGAGE_ACCOUNT("mortgage account"),
    GIC_ACCOUNT("gic account"),
    JOINT_CHEQUING_ACCOUNT("joint chequing account");

    private String accountType;

    AccountType(String accountType){
        this.accountType = accountType;
    }

    @Override
    public String toString(){
        return this.accountType;
    }

    /*
    The function of this method belongs in BankClientViewControl. See displayAccountRequest method in BankClientViewControl.


    public static AccountType parseAccountType(String accountString) throws NoSuchAccountException {
        for (AccountType account : AccountType.values()){
            if (account.toString().equals(accountString)){
                return account;
            }
        }
        throw new NoSuchAccountException();
    }
     */


    /**
     * Returns a string representation of all account types.
     * @return a string representation of all account types.
     */
    public static String allTypes() {
        String all = "";
        char alphabet = 'A';

        for (AccountType account : AccountType.values()) {
            all += alphabet + "." + account.toString() + "\n";
            alphabet++;
        }
        return all;
    }
}
