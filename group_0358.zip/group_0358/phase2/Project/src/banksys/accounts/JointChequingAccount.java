package banksys.accounts;

import banksys.system_managers.DateManager;
import banksys.currency.CurrencyType;

public class JointChequingAccount extends ChequingAccount {
    private int owners;

    public JointChequingAccount(int accountNum, DateManager currDate){
        super(accountNum, currDate);
        this.accountType = AccountType.JOINT_CHEQUING_ACCOUNT;
        this.owners = 0;
    }

    public JointChequingAccount(int accountNum, DateManager currDate, CurrencyType preferredCurrency){
        super(accountNum, currDate, preferredCurrency);
        this.accountType = AccountType.JOINT_CHEQUING_ACCOUNT;
        this.owners = 1;
    }

    public int getOwners(){
        return this.owners;
    }

    public void addOwner(){
        this.owners += 1;
    }

    public boolean jointOwned(){
        return this.owners == 2;
    }

    @Override
    public CurrencyType getCurrency() {
        return this.currencyType;
    }

    @Override
    public String toString() {
        return "Joint Chequing #" + this.accountNum;
    }






}
