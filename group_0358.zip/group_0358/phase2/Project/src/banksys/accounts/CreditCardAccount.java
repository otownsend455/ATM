package banksys.accounts;

import banksys.system_managers.DateManager;
import banksys.currency.CurrencyType;

/**
 * Represents a credit card account.
 */
public class CreditCardAccount extends DebtAccount {

    CreditCardAccount(int accountNum, DateManager currDate) {
        super(accountNum, currDate);
        setCreditLimit(10000);
        this.accountType = AccountType.CREDIT_CARD_ACCOUNT;
    }

    CreditCardAccount(int accountNum, DateManager currDate, CurrencyType preferredCurrency) {
        super(accountNum, currDate, preferredCurrency);
        setCreditLimit(10000);
        this.accountType = AccountType.CREDIT_CARD_ACCOUNT;
    }

    @Override
    public CurrencyType getCurrency() {
        return this.currencyType;
    }

    @Override
    public String toString() {
        return "Credit Card #" + this.accountNum;
    }

    /**
     * Returns false since a client is unable to transfer out money from Credit Card account.
     * @param amount amount client wishes to withdrawal
     * @return false
     */
    public boolean validTransferOut(double amount){
        return false;
    }
}
