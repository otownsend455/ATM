package banksys.accounts;

import banksys.system_managers.DateManager;
import banksys.currency.CurrencyType;

/**
 * An abstraction of a savings and line of credit account.
 */
public abstract class AssetAccount extends GeneralAccount implements TransferableAccount {
    private double overdraftLimit;

    public AssetAccount (int accountNum, DateManager currDate) {
        super(accountNum, currDate);
    }

    public AssetAccount (int accountNum, DateManager currDate, CurrencyType preferredCurrency) {
        super(accountNum, currDate, preferredCurrency);
    }

    public double getOverDraftLimit(){
        return this.overdraftLimit;
    }


    /**
     * Represents how much can be overdrawn. e.g. if overdraft limit is 100,
     * and a client's current balance is $0, then the maximum they can withdrawal is -$100.
     * @param amount amount that can be overdrawn.
     */
    public void setOverdraftLimit(double amount) {
        this.overdraftLimit = amount;
    }

    /**
     * @param amount amount being transferred in
     * @param description description of transaction
     */
    public void transferIn(double amount, String description) {
        this.balance += amount;
    }

    /*
    public void transferOut(double amount) throws OverdraftLimitException, TransferOutDeniedException {
        if (this.balance - amount >= this.overdraftLimit) {
            this.balance -= amount;
        } else if (this instanceof ChequingAccount && this.balance <= 0) {
            throw new TransferOutDeniedException();
        }
        else throw new OverdraftLimitException();
    }
     */

    public boolean validTransferOut(double amount){
        return (this.balance - amount) >= -this.overdraftLimit; // remember overdraftLimit is the amount that can be OVERDRAWN
    }


    /**
     * @param amount amount being transferred out
     * @param description description of transaction
     */
    public void transferOut(double amount, String description) {
        this.balance -= amount;
    }


}
