package banksys;
import banksys.view_controls.BankCentralViewControl;

/**
 * Reperesents where the program starts.
 */
public class Starter {

    public static void main(String[] args) {
        BankCentralViewControl atm = new BankCentralViewControl();
        atm.runBank();
    }
}
