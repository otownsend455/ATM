package banksys.view_controls;

import banksys.bankworkers.BankTeller;
import banksys.system_managers.DateManager;
import banksys.bankworkers.BankManager;
import banksys.filehandler.SerializableObjectData;
import banksys.filehandler.SerializableObjectOperator;
import banksys.system_managers.MoneyManager;
import banksys.system_managers.UserManager;

import javax.swing.*;
import java.io.*;
import java.util.*;

/**
 * Represents the central control system of the bank.
 */
public class BankCentralViewControl{

    BankManager bm;
    UserManager userManager;
    DateManager date;
    MoneyManager moneyManager;
    boolean firstTimeSettingDate;
    boolean bankManagerHasShutOffATM;
    BankTeller teller;

    public BankCentralViewControl(){
        this.date = getDate();
        setDate(date);
        this.userManager = new UserManager(date);
        this.moneyManager = new MoneyManager();
        updateUserManager();
        bm = new BankManager("username", "password", date, moneyManager);
        this.userManager.addBankWorker(bm);
        firstTimeSettingDate = false;
        this.bankManagerHasShutOffATM = false;
        teller = new BankTeller("bankteller", "bankteller", moneyManager);
        this.userManager.addBankWorker(teller);
    }

    public void runBank() {
        moneyManager.readBillsFromFile();
        date.addObserverList(userManager.getClientSoftLog());
        date.notifyObservers();
        while (!bankManagerHasShutOffATM) {
            String[] choices = {"1. Login as a bank worker",
                    "2. Login as a client"};
            String choice = (String)JOptionPane.showInputDialog(null,
                    "Welcome to the bank!", "menu",
                    JOptionPane.QUESTION_MESSAGE, null, choices, "Choose One");
            int input = Integer.parseInt(choice.replaceAll("[\\D]",""));

            if (input == 1){
                loginAsBankWorker();
                if (bankManagerHasShutOffATM && !firstTimeSettingDate) {
                    date.incrementDate();
                    setDate(date);
                }
            }
            else if(input == 2){
                loginAsClient();
            }

            HashMap clientsSet = userManager.getClientSoftLog();
            writeUsersToFile(clientsSet, "clients");
            moneyManager.billsToFile();
        }
    }


    private void loginAsBankWorker() {
        boolean runBankWorkerLoginPanel = true;
        while (runBankWorkerLoginPanel) {
            String userInput = JOptionPane.showInputDialog("Please enter your username or 'x' to go back.\n");

            if (userInput.equals("x")) {
                runBankWorkerLoginPanel = false;
            }
            else if (userManager.isValidUsername("bankworker", userInput)) {
                String bankWorkerUsername = userInput;
                boolean runBankWorkerPasswordPanel = true;
                while (runBankWorkerPasswordPanel) {
                    userInput = JOptionPane.showInputDialog("Welcome, " + bankWorkerUsername +
                            ".  Please" + " enter your password or 'x' to go back");
                    if (userManager.isValidPassword("bankworker", bankWorkerUsername, userInput)) {
                        runBankWorkerLoginPanel = runBankWorkerPasswordPanel = false;
                        if (bankWorkerUsername.endsWith("*BT*")) {
                            BankWorkerViewControl bmwc = new BankWorkerViewControl(this,
                                    userManager.getBankWorker(bankWorkerUsername), userManager, date);
                            bmwc.runWorkerControl();

                        } else {
                            BankManagerViewControl bmmc = new BankManagerViewControl(this,
                                    bm, userManager, date);
                            this.bankManagerHasShutOffATM = bmmc.runManagerControl();

                        }
                    } else if (userInput.equals("x")) {
                        runBankWorkerPasswordPanel = false;
                    }
                }
            } else {
                viewControlInvalidInput();
            }
        }
    }

    private void loginAsClient(){
        boolean runClientLoginPanel = true;
        while (runClientLoginPanel){
            String userInput=JOptionPane.showInputDialog("Please enter your username or 'x' to go back.\n");
            if (userInput.equals("x")){
                runClientLoginPanel = false;
            }
            else if (userManager.isValidUsername("client", userInput)){
                String clientUsername = userInput;
                boolean runClientPasswordPanel = true;
                while(runClientPasswordPanel){
                    userInput = JOptionPane.showInputDialog("Welcome, " + clientUsername +
                            ".  Please" + " enter your password or 'x' to go back");
                    if (userManager.isValidPassword("client", clientUsername, userInput)){
                        BankClientViewControl bmuc = new BankClientViewControl(this, userManager.getClient(clientUsername), date, this.userManager);
                        bmuc.runMainMenu();
                        runClientPasswordPanel = runClientLoginPanel = false;

                    }
                    else if(userInput.equals("x")){
                        runClientPasswordPanel = false;
                    }
                }
            }
            else{
                viewControlInvalidInput();
            }
        }
    }


    /**
     * Display & control invalid input pop-up.
     */
    private void viewControlInvalidInput(){
        JFrame frame = new JFrame();
        JOptionPane.showMessageDialog(frame,
                "Invalid input. Please enter an option specified in the panel.",
                "Invalid input",
                JOptionPane.WARNING_MESSAGE);
    }


    /**
     * Set the firstTimeSettingDate to true in order for the program to not increment the date when
     * the bank manager shuts off the program.
     * @param aboutToSet represents the first time the bank manager sets the date. This must be true.
     */
    public void setFirstTimeSettingDate(boolean aboutToSet){
        if (aboutToSet == true){
            this.firstTimeSettingDate = aboutToSet;
        }
    }


    private void updateUserManager(){
        this.userManager.updateUserSoftLog();

    }


    public static DateManager getDate(){
        DateManager date = null;
        try{
            FileReader fr = new FileReader(new File("").getAbsoluteFile() + "/Project/src/banksys/txtfile/date.txt");
            BufferedReader br = new BufferedReader(fr);
            int day = Integer.parseInt(br.readLine());
            int month = Integer.parseInt(br.readLine());
            int year = Integer.parseInt(br.readLine());
            date = new DateManager(day, month, year);
            br.close();
            fr.close();
        } catch(IOException e){
            System.out.println("Error: " + e);
        }
        return date;
    }

    public void setDate(DateManager date){
        String stringDate = date.getDay() + "\n" + date.getMonth() + "\n" + date.getYear();
        try{
            FileWriter fw = new FileWriter(new File("").getAbsoluteFile() + "/Project/src/banksys/txtfile/date.txt");
            BufferedWriter bw = new BufferedWriter(fw);
            bw.write(stringDate);
            bw.close();
            fw.close();
        } catch(IOException e){
            System.out.println("Error: " + e);
        }
    }

    private void writeUsersToFile(HashMap serObj, String option) {
        File f;
        //if (option == "clients") {
        f = new File(new File("").getAbsoluteFile() + "/Project/src/banksys/txtfile/clientHardLog.txt");
        //} else {
        //    f = new File("phase2/Project/src/banksys/txtfile/bankWorkerHardLog.txt");
        SerializableObjectOperator soo = new SerializableObjectOperator(f);
        soo.clearFile();
        SerializableObjectData sod = new SerializableObjectData(serObj);
        soo.writeData(sod);
    }
}
