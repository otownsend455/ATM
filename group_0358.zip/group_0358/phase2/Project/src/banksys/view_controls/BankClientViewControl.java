package banksys.view_controls;

import banksys.Client;
import banksys.system_managers.DateManager;
import banksys.accounts.*;
import banksys.system_managers.TransferManager;
import banksys.system_managers.UserManager;

import javax.swing.*;
import java.util.ArrayList;

class BankClientViewControl {

    private Client client;
    private DateManager date;
    private UserManager userManager;
    private BankCentralViewControl centralControl;

    /**
     * RECENT IMPLEMENTATIONS: most of the switch statement methods are done.
     */
    BankClientViewControl(BankCentralViewControl centralControl, Client client, DateManager date, UserManager userManager) {
        this.centralControl = centralControl;
        this.client = client;
        this.date = date;
        this.userManager = userManager;
    }


    void runMainMenu() {
        // TODO include as choices "change currency" and "request creation of a product account (morgage, GIC)"
        // TODO add morgage and GIC to net-total calculation (in client class)
        String[] choices = {"1. View account balances and net-total",
                "2. Perform a transfer (to user, non-user, to another account)",
                "3. Withdraw cash",
                "4. Deposit cash",
                "5. Request creation of a new account (Transferable or Product)",
                "6. View recent transactions",
                "7. View date of creation for an account",
                "8. Reset primary chequing account",
                "9. Change password",
                "10. Share an account",
                "11. Log out"};
        int input = 0;
        while (input != 11) {

            String choice = (String)JOptionPane.showInputDialog(null,
                    "Welcome, " + client.getUsername() + ". ", "User menu",
                    JOptionPane.QUESTION_MESSAGE, null, choices, "Choose One");
            input = Integer.parseInt(choice.replaceAll("[\\D]",""));

            switch (input) {
                case 1:
                    viewControlBalances();
                    break;
                case 2:
                    viewControlGeneralTransfer();
                    break;
                case 3:
                    viewControlWithdrawingCash();
                    break;
                case 4:
                    viewControlDepositingCash();
                    break;
                case 5:
                    viewControlAccountRequest();
                    break;
                case 6:
                    viewControlRecentTransactions();
                    break;
                case 7:
                    viewControlAccountCreationDates();
                    break;
                case 8:
                    viewControlResetPrimaryChequing();
                    break;
                case 9:
                    viewControlChangePassword();
                    break;
                case 10:
                    viewControlShareAccount();
                case 11:
                    JOptionPane.showMessageDialog(null, "Thank you for using this ATM, please" +
                            " come again");
                    break;
                default:
                    viewControlInvalidInput();
                    break;
            }
        }
    }


    /**
     * Display & control invalid input pop-up.
     */
    private void viewControlInvalidInput(){
        JFrame frame = new JFrame();
        JOptionPane.showMessageDialog(frame,
                "Invalid input. Please enter an option specified in the panel.",
                "Invalid input",
                JOptionPane.WARNING_MESSAGE);
    }

    /**
     * Display & control insufficient funds to withdraw
     */
    private void viewControlInsufficientFunds(TransferableAccount transferableAccount){
        JFrame frame = new JFrame();

        if (transferableAccount instanceof AssetAccount){
            JOptionPane.showMessageDialog(frame,
                    "Insufficient funds in " + transferableAccount.toString() + ". \n" + "Amount requested to transfer out would exceed this accounts " +
                            "overdraft limit of " + ((AssetAccount) transferableAccount).getOverDraftLimit() + ". ",
                    "Exceeded overdraft limit.",
                    JOptionPane.WARNING_MESSAGE);
        }
        else if(transferableAccount instanceof DebtAccount){
            JOptionPane.showMessageDialog(frame,
                    "Insufficient funds in " + transferableAccount.toString() + ".\n" + "Amount requested to transfer out would exceed this accounts " +
                            "credit limit of " + (((DebtAccount) transferableAccount).getCreditLimit()) + ". ",
                    "Exceeded credit limit.",
                    JOptionPane.WARNING_MESSAGE);
        }
    }


    /**
     * Display & control all transfer options made by the client (to user, non-user, to another account)
     */
    private void viewControlGeneralTransfer(){

        boolean runIterator = true;
        while(runIterator){
            String userInput = JOptionPane.showInputDialog("Enter 'A' to transfer to another account\n" +
                    "Enter 'B' to transfer to a non-user\n" +
                    "Enter 'C' to transfer to another user\n" +
                    "Enter 'x' to go back to previous options");

            if(userInput.equals("x")){
                runIterator = false;


            }
            else if(userInput.matches("A|B|C")){
                String transferType = userInput;
                boolean runInnerIterator = true;
                while(runInnerIterator){
                    userInput = JOptionPane.showInputDialog("Enter the amount you would like to transfer or enter 'x' to go back");
                    if(userInput.equals("x")){
                        runInnerIterator = false;
                    }
                    else if(userInput.matches("-?\\d+(\\.\\d+)?")) {
                        double transferOutAmount = Double.parseDouble(userInput);

                        boolean runSecondInnerIterator = true;
                        while (runSecondInnerIterator) {
                            userInput = JOptionPane.showInputDialog("Which account would you like to transfer $" + transferOutAmount + " from?\n" +
                                    createTransferOutAccountsPanel() + "Enter 'x' to go back");
                            if (userInput.equals("x")) {
                                runSecondInnerIterator = false;
                            } else {
                                Integer accountIndexToTransferFrom = Integer.parseInt(userInput);
                                if (accountIndexToTransferFrom < client.getallTransferAccounts().size()){
                                    TransferableAccount transferFrom = client.getTransferOutAccounts().get(accountIndexToTransferFrom);
                                    if (transferFrom.validTransferOut(transferOutAmount)){
                                        controlSpecificTransferMethodCalls(transferType, transferFrom, transferOutAmount);
                                        runIterator = runInnerIterator = runSecondInnerIterator = false;
                                    }
                                    else{
                                        viewControlInsufficientFunds(transferFrom);
                                    }
                                }
                                else {
                                    viewControlInvalidInput();
                                }
                            }
                        }
                    }
                }
            }
            else{
                viewControlInvalidInput();
            }
        }
    }


    /**
     * Displays & controls getting amount to transfer and then calling helper methods based on transferType
     * @param transferType "A": transfer to another account, "B". transfer to a non-user, "C". transfer to a user
     */
    private void controlSpecificTransferMethodCalls(String transferType, TransferableAccount transferFrom, double transferOutAmount){
        if(transferType.equals("A")){
            viewControlTransferToAnotherAccount(transferFrom, transferOutAmount);
        }
        else if(transferType.equals("B")){
            viewControlTransferToNonUser(transferFrom, transferOutAmount);
        }
        else if(transferType.equals("C")){
            viewControlTransferToUser(transferOutAmount);
        }
    }


    /**
     * Display & control transfer to another account of this client
     */
    private void viewControlTransferToAnotherAccount(TransferableAccount transferFrom, Double transferOutAmount){
        boolean runIterator = true;
        while (runIterator){
            String userInput = JOptionPane.showInputDialog("Which account would you like to transfer $" + transferOutAmount + " to?\n" +
                    createTransferableAccountsOptionPanel(transferFrom) + "Enter 'x' to go back");
            if(userInput.equals("x")){
                runIterator = false;
                viewControlGeneralTransfer();
            }
            else{
                Integer accountIndexToTransferTo = Integer.parseInt(userInput);
                if (accountIndexToTransferTo < client.getTransferOutAccounts().size()){
                    TransferableAccount transferTo = client.getTransferOutAccounts().get(accountIndexToTransferTo);
                    new TransferManager().transferBetweenAccounts(transferFrom, transferTo, transferOutAmount, "Transfer made to account: " + transferTo.getAccountNum());
                    JFrame frame = new JFrame();
                    JOptionPane.showMessageDialog(frame, "Successful transfer was made from " + transferFrom.toString() + " to " + transferTo.toString() + "!" ,"Successful transfer", JOptionPane.PLAIN_MESSAGE);
                    runIterator = false;
                }
                else{
                    viewControlInvalidInput();
                }
            }
        }
    }


    /**
     * Display & control transfer to a non-user (pay a bill)
     */
    private void viewControlTransferToNonUser(TransferableAccount transferFrom, Double transferOutAmount){
        String transferTo = JOptionPane.showInputDialog("Please enter the non-user who you are transferring to.");
        new TransferManager().transferToNonUser(transferFrom, transferOutAmount, " Transfer made to non-user: " + transferTo, client.getUsername());
        JOptionPane.showMessageDialog(null, "Successful transfer was made from " + transferFrom.toString() + " to " + transferTo + "!" ,"Successful transfer", JOptionPane.PLAIN_MESSAGE);
    }

    /**
     * Display & control transfer to another user
     */
    private void viewControlTransferToUser(Double transferOutAmount){
        boolean run = true;

        while(run){
            String userInput = JOptionPane.showInputDialog("Enter below a valid user to transfer " + transferOutAmount + " to:\n" +
                    "Or enter 'x' to go back");
            if (userInput.equals("x")){
                run = false;
            }
            else if(userManager.isValidUsername("client", userInput)){
                Client clientTransferringTo = userManager.getClient(userInput);
                new TransferManager().transferToUser(clientTransferringTo, client, transferOutAmount, "Transfer made to user: " + clientTransferringTo.getUsername());
                JFrame frame = new JFrame();
                JOptionPane.showMessageDialog(frame, "Successful transfer was made from " + client.toString() + " to " + clientTransferringTo.getUsername() + "!" ,"Successful transfer", JOptionPane.PLAIN_MESSAGE);
                run = false;
            }
            else{
                viewControlInvalidInput();
            }
        }

    }

    /**
     * OPTION PANEL CREATION METHODS BELOW (createTransferOutAccountPanel, createTransferableAccountOptionPanel, createNonPrimaryChequingOptionPanel)
     */

    /**
     * Creates an option panel composed of all accounts that can transfer out money (digital and physical).
     * This includes transferable accounts that client owns, besides Credit Card accounts, will be an option created by this panel.
     * @return an option panel composed of all accounts that can transfer out money (digital and physical)
     */
    private String createTransferOutAccountsPanel(){
        ArrayList transferOutAccounts = client.getTransferOutAccounts();
        String transferOutAccountsPanel = "";

        if (transferOutAccounts.size() > 0){
            for (int i = 0; i < transferOutAccounts.size(); i++){
                transferOutAccountsPanel = transferOutAccountsPanel + "Enter " + " '" + i + "'" + " for " + transferOutAccounts.get(i) + "\n";
            }
        }
        else{
            transferOutAccountsPanel = "\nATTENTION: You have no accounts available to transfer out from.\n\n";
        }

        return transferOutAccountsPanel;
    }

    /**
     * @return an option panel composed of all transferable accounts.
     */
    private String createTransferableAccountsOptionPanel(){
        ArrayList<TransferableAccount> transferableAccounts = new ArrayList<>(client.getallTransferableAccounts().values());

        String transferableAccountsOptionPanel = "";

        if(transferableAccounts.size() > 0){
            for (int i = 0; i < transferableAccounts.size(); i++){
                transferableAccountsOptionPanel = transferableAccountsOptionPanel + "Enter " + " '" + i + "'" + "for " + transferableAccounts.get(i) + "\n";
            }
        }
        else{
            transferableAccountsOptionPanel = "\nATTENTION: You have no accounts available to transfer out from.\n\n";
        }

        return transferableAccountsOptionPanel;
    }

    /**
     * The utility of this option panel is when a client is performing the act of
     * transferring between accounts. When a client is selecting which account to transfer to,
     * the bank interface should not show as an option the account that the client is transferring from.
     * @return an option panel composed of all transferable accounts MINUS transferingFromAccount.
     */
    private String createTransferableAccountsOptionPanel(TransferableAccount transferringFromAccount){
        ArrayList<TransferableAccount> transferableAccounts = new ArrayList<>(client.getallTransferableAccounts().values());

        String transferableAccountsOptionPanel = "";

        if(transferableAccounts.size() - 1 > 0){
            for (int i = 0; i < transferableAccounts.size(); i++){
                if (transferringFromAccount.getAccountNum() != transferableAccounts.get(i).getAccountNum()){
                    transferableAccountsOptionPanel = transferableAccountsOptionPanel + "Enter " + " '" + i + "'" + "for " + transferableAccounts.get(i) + "\n";
                }
            }
        }
        else{
            transferableAccountsOptionPanel = "\nATTENTION: You currently have no accounts available to transfer to.\n\n";
        }

        return transferableAccountsOptionPanel;
    }


    /**
     * Create option panel for non-primary chequing accounts (used in viewControlResetPrimaryAccount method)
     */
    private String createNonPrimaryChequingOptionPanel(){
        ArrayList<ChequingAccount> chequingAccounts = new ArrayList<>(client.getChequingAccounts().values());

        String nonPrimaryChequingAccountsOptionPanel = "";

        if(chequingAccounts.size() - 1 > 0){
            for (int i = 0; i < chequingAccounts.size(); i++){
                if(chequingAccounts.get(i).getAccountNum() != client.getPrimaryAccountNum()){
                    nonPrimaryChequingAccountsOptionPanel = nonPrimaryChequingAccountsOptionPanel + "Enter " + " '" + (i - 1) + "'" + " for " + chequingAccounts.get(i) + "\n";
                }
            }
        }
        else{
            nonPrimaryChequingAccountsOptionPanel = "\nATTENTION: You currently have no other chequing account to be reset as the new primary account.\n\n";
        }

        return nonPrimaryChequingAccountsOptionPanel;
    }


    private String createProductAccountOptionPanel(){
        ArrayList<Account> productAccounts = new ArrayList<>(client.getallProductAccounts().values());

        String productAccountOptionPanel = "";

        if(productAccounts.size() > 0){
            for (int i = 0; i < productAccounts.size(); i++){
                if(productAccounts.get(i).getAccountNum() != client.getPrimaryAccountNum()){
                    productAccountOptionPanel = productAccountOptionPanel + "Enter " + " '" + (i + 4) + "'" + " for " + productAccounts.get(i) + "\n";
                }
            }
        }
        else{
            productAccountOptionPanel = "\nATTENTION: You currently have no product accounts.\n\n";
        }

        return productAccountOptionPanel;
    }

    /**
     * Display & control all account balances and net total
     */
    private void viewControlBalances(){
        String netTotal = "Net total: " + client.calculateNetTotal() + "\n";
        String allAccountBalances = "";

        ArrayList<TransferableAccount> allAccountsArray = new ArrayList<>(client.getallTransferableAccounts().values());
        for (TransferableAccount currAccount: allAccountsArray){
            allAccountBalances = allAccountBalances + currAccount.toString() + ": " + currAccount.getBalance() + "\n";
        }
        ArrayList<Account> allProductsArray = new ArrayList<>(client.getallProductAccounts().values());
        for (Account currAccount: allProductsArray){
            allAccountBalances = allAccountBalances + currAccount.toString() + ": " + currAccount.getBalance() + "\n";
        }
        JOptionPane.showMessageDialog(null, netTotal + allAccountBalances);


    }

    private void viewControlShareAccount(){
        JFrame frame = new JFrame();
        JOptionPane.showMessageDialog(frame,
                "If you want to create a joint account,\n" +
                        "please go to the main menu and select 'Request creation of a new account'." +
                        "From there, you can select whether you wish to create a new account that is joint.\n" +
                        "Please note that you can only create joint chequing accounts.\n");
    }

    /**
     * Display & control withdrawing cash
     */
    private void viewControlWithdrawingCash(){

        // OUTER ITERATOR: gets amount to withdrawal
        boolean runOuterIterator = true;
        while(runOuterIterator){
            String userInput = JOptionPane.showInputDialog("Enter the amount you would like to withdrawal or enter 'x' to go back\n\n(NOTE: the amount requested " +
                    "to withdrawal must be a factor of 5 in order provide you with the correct bill denomination)");
            if(userInput.equals("x")){
                runOuterIterator = false;
            }
            else{
                try
                {
                    double withdrawalAmount = Double.parseDouble(userInput);;
                    if (withdrawalAmount % 5 == 0){
                        // INNER ITERATOR: gets account to withdrawal from & perform withdrawal
                        boolean runInnerIterator = true;
                        while(runInnerIterator){
                            userInput = JOptionPane.showInputDialog("Which account would you like to withdrawal $" + userInput + " from?\n" +
                                    createTransferOutAccountsPanel() + "Or enter 'x' to go back");
                            if (userInput.equals("x")) {
                                runInnerIterator = false;
                            }
                            else{
                                int accountIndexToTransferFrom = Integer.parseInt(userInput);
                                if (accountIndexToTransferFrom < client.getTransferOutAccounts().size()){
                                    TransferableAccount transferFrom = client.getTransferOutAccounts().get(accountIndexToTransferFrom);
                                    if (transferFrom.validTransferOut(withdrawalAmount)){
                                        client.withdraw((int)withdrawalAmount, transferFrom);
                                        JFrame frame = new JFrame();
                                        JOptionPane.showMessageDialog(frame, "Successfully withdrew $" + withdrawalAmount + " from " + transferFrom.toString() + ".\n" +
                                                "New balance of " + transferFrom.toString() + ": $" + transferFrom.getBalance());
                                        runInnerIterator = runOuterIterator = false;
                                    }
                                    else{
                                        viewControlInsufficientFunds(transferFrom);
                                    }
                                }
                                else{
                                    viewControlInvalidInput();
                                }
                            }
                        }
                    }
                }
                catch(NumberFormatException e)
                {
                    viewControlInvalidInput();
                }
            }
        }
    }

    /**
     * Display & control depositing cash
     */
    private void viewControlDepositingCash(){
        JFrame frame = new JFrame();
        Object[] options = {"Neither, go back to main menu", "Cash",
                "Cheque"};
        double prevBalance = 0.0; // placeholder value
        int userInput = 6; // placeholder value (must be greater than 2)

        boolean invalidInput = true;
        while (invalidInput) {
            userInput = JOptionPane.showOptionDialog(frame,
                    "Would you like to deposit cash or cheque?:",
                    "Making a deposit",
                    JOptionPane.YES_NO_CANCEL_OPTION,
                    JOptionPane.QUESTION_MESSAGE,
                    null,
                    options,
                    options[2]);
            if (userInput == 1) {
                prevBalance = client.getPrimaryAccount().getBalance();
                client.deposit(1); // deposit cash
                invalidInput = false;
            } else if (userInput == 2) {
                prevBalance = client.getPrimaryAccount().getBalance();
                client.deposit(2); // deposit cheque
                invalidInput = false;
            } else {
                invalidInput = false;
            }
        }

        if (userInput < 3){
            double newBalance = client.getPrimaryAccount().getBalance();
            double amountDeposited = newBalance - prevBalance;
            frame = new JFrame();
            JOptionPane.showMessageDialog(frame, "Successfully deposited $" + amountDeposited + " to primary chequing account.\n" +
                    "New primary chequing account balance: $" + client.getPrimaryAccount().getBalance());
        }
    }

    /**
     * Display & control recent transactions
     */
    private void viewControlRecentTransactions(){

        // OUTER ITERATOR: gets account x to view recent transactions of
        boolean runOuterIterator = true;
        while(runOuterIterator){
            String userInput = JOptionPane.showInputDialog("Which account would you like to view the recent transactions of?\n" +
                    createTransferableAccountsOptionPanel() + createProductAccountOptionPanel());
            if(userInput.equals("x")){
                runOuterIterator = false;

            }
            else{
                Integer indexOfAccountToView = Integer.parseInt(userInput);
                if (indexOfAccountToView < client.getallTransferableAccounts().size()){
                    TransferableAccount accountToView = client.getallTransferAccounts().get(indexOfAccountToView);

                    // INNER ITERATOR: gets how many recent transaction to be viewed
                    boolean runInnerIterator = true;
                    while(runInnerIterator){
                        userInput = JOptionPane.showInputDialog("How many transactions would you like view?\n" + "Or enter 'x' to go back");
                        if (userInput.equals("x")){
                            runInnerIterator = false;
                        }
                        else if(userInput.matches("\\d+")){
                            int numTransactions = Integer.parseInt(userInput);


                            //String recentTransaction = client.getRecentTransactions(accountToView.getAccountNum(), numTransactions);
                            //System.out.println(client.getRecentTransactions(accountToView.getAccountNum(), numTransactions));
                            String recentTransaction = client.getRecentTransactions(accountToView.getAccountNum(), numTransactions);
                            // SECOND INNER ITERATOR: displays recent transactions of account x
                            boolean runSecondInnerIterator = true;
                            while(runSecondInnerIterator){
                                // TODO does not show transactions of morgage and GIC
                                recentTransaction = client.getRecentTransactions(accountToView.getAccountNum(), numTransactions);
                                JFrame frame = new JFrame();
                                JOptionPane.showMessageDialog(frame, "Recent transaction of" + accountToView.toString() + ":\n" +
                                        recentTransaction);


                                runOuterIterator = runInnerIterator = runSecondInnerIterator = false;
                            }
                        }
                        else{
                            viewControlInvalidInput();
                        }
                    }
                }
                else{
                    viewControlInvalidInput();
                }
            }
        }
    }



    /**
     * Display & control account creation dates of all accounts
     */
    private void viewControlAccountCreationDates(){

        String accountCreationDateString = "";

        ArrayList<TransferableAccount> allAccountsArray = new ArrayList<>(client.getallTransferableAccounts().values());
        for (TransferableAccount currAccount: allAccountsArray){
            accountCreationDateString = accountCreationDateString + currAccount.toString() + "- " + currAccount.getCreationDate() + "\n";
        }
        ArrayList<Account> allProductsArray = new ArrayList<>(client.getallProductAccounts().values());
        for (Account currAccount: allProductsArray){
            accountCreationDateString = accountCreationDateString + currAccount.toString() + ": " + currAccount.getCreationDate() + "\n";
        }

        boolean run = true;
        while(run){
            String inputValue = JOptionPane.showInputDialog("Creation dates of all accounts:\n" + accountCreationDateString + "Enter 'x' to go back");
            if (inputValue.matches("x|X")){
                run = false;
            }
        }
    }

    /**
     * Display & control change password
     */
    private void viewControlChangePassword() {

        boolean runIterator = true;
        while(runIterator){
            String userInput = JOptionPane.showInputDialog("Current password: " + client.getPassword() + "\n" + "Please enter below the new password you want:\nInput 'x' to return to the menu.");
            if (userInput.equals("x")){
                runIterator = false;
            }
            else if(userInput.matches("^[a-zA-Z0-9]+([a-zA-Z0-9](_|-)[a-zA-Z0-9])*[a-zA-Z0-9]+$") && userInput.length() > 3){
                client.setPassword(userInput);
                JOptionPane.showMessageDialog(null, "Your password has been changed successfully.");
                runIterator = false;
                if(client.getUsername().endsWith("*BT*")) {
                    userManager.getBankWorker(client.getUsername()).setPassword(userInput);
                }
            }
            else{
                viewControlInvalidInput();
            }
        }
    }

    /**
     * Display & control primary chequing account that the client has to a different chequing account.
     */
    private void viewControlResetPrimaryChequing(){

        // ITERATOR: gets chequing account x to set as the primary account
        boolean runIterator = true;
        while (runIterator) {
            // TODO if there's only one chequing account
            String userInput = JOptionPane.showInputDialog("Current primary account: " + client.getPrimaryAccount().toString() + "\n" +
                    "Which other chequing account do you want to become your new primary account?\n" + createNonPrimaryChequingOptionPanel() + "Or enter 'x' to go back");
            if (userInput.equals("x")) {
                runIterator = false;
            }
            else{
                if(client.getChequingAccounts().size() - 1 > 0){
                    Integer indexChequingAccount = Integer.parseInt(userInput);
                    if(indexChequingAccount < client.getChequingAccounts().size() - 1){
                        ArrayList<ChequingAccount> chequingAccounts = new ArrayList<>(client.getChequingAccounts().values());
                        ChequingAccount newPrimaryChequing = chequingAccounts.get(indexChequingAccount);
                        client.setPrimary(newPrimaryChequing);
                        JFrame frame = new JFrame();
                        JOptionPane.showMessageDialog(frame, "Successful primary account reset!\n" + "New primary account: " + newPrimaryChequing.toString() ,"Sucessful deposit", JOptionPane.PLAIN_MESSAGE);
                        runIterator = false;

                    }
                    else{
                        viewControlInvalidInput();
                    }
                }
            }
        }
    }



    private void viewControlAccountRequest(){

        AccountType accountEnum = null;

        String choices[] = {"1. Chequing Account", "2. Credit Card Account", "3. Line of Credit Account",
                "4. Savings Account", "5. Mortgage Account", "6. GIC Account", "7. Return to Menu"};
        String choice = (String)JOptionPane.showInputDialog(null,
                "Please select the account type you wish to create.", "User menu",
                JOptionPane.QUESTION_MESSAGE, null, choices, "Choose One");

        int input = Integer.parseInt(choice.replaceAll("[\\D]",""));


        if (input < 5) {
            if (input == 1) {
                String yesNoChoices[] = {"Yes", "No"};
                choice = (String)JOptionPane.showInputDialog(null,
                        "Would you like this chequing account to be joint?.", "Joint option",
                        JOptionPane.QUESTION_MESSAGE, null, yesNoChoices, "Choose One");
                if (choice.equals("Yes")){
                    String userInput = JOptionPane.showInputDialog("Please enter the user who you would like to make this joint account with.");
                    if(userManager.isValidUsername("client", userInput)){
                        Client clientToHaveJoint = userManager.getClient(userInput);
                        accountEnum = AccountType.JOINT_CHEQUING_ACCOUNT;
                        clientToHaveJoint.requestNewAccount(accountEnum);
                    }
                }
                else{
                    accountEnum = AccountType.CHEQUING_ACCOUNT;
                }
            } else if (input == 2) {
                accountEnum = AccountType.CREDIT_CARD_ACCOUNT;
            } else if (input == 3) {
                accountEnum = AccountType.LINE_OF_CREDIT_ACCOUNT;
            } else if (input == 4) {
                accountEnum = AccountType.SAVINGS_ACCOUNT;
            }
            client.requestNewAccount(accountEnum);
            JOptionPane.showMessageDialog(null, "Account request has been sent. The bank manager will accept your request shortly.");
        } else if (input < 7) {
            if (input == 5) {
                accountEnum = AccountType.MORTGAGE_ACCOUNT;
            } else if (input == 6) {
                accountEnum = AccountType.GIC_ACCOUNT;
            }
            String amount = JOptionPane.showInputDialog("Amount of money for this product:");
            String duration = JOptionPane.showInputDialog("How long will you keep this product?");
            client.requestNewProduct(accountEnum, Double.parseDouble(amount), Integer.parseInt(duration));
            JOptionPane.showMessageDialog(null, "Product request has been sent. The bank manager will accept your request shortly.");
        }

    }


}
