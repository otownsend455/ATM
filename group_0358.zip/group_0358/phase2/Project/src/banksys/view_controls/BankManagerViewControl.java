package banksys.view_controls;

import banksys.Client;
import banksys.accounts.Account;
import banksys.system_managers.DateManager;
import banksys.accounts.ChequingAccount;
import banksys.accounts.TransferableAccount;
import banksys.bankworkers.*;
import banksys.currency.CurrencyType;
import banksys.system_managers.TransferManager;
import banksys.system_managers.UserManager;

import javax.swing.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

class BankManagerViewControl extends BankWorkerViewControl {
    private BankManager bankManager;
    private Icon icon;

    BankManagerViewControl(BankCentralViewControl centralControl, BankManager bm, UserManager userManager, DateManager date) {
        super(centralControl, bm, userManager, date);
        bankManager = bm;
        icon = new ImageIcon(new File("").getAbsoluteFile() + "/Project/src/banksys/coins.png");
    }

    boolean runManagerControl() {
        String[] choices = {"1. Create a new client",
                "2. Restock the ATM",
                "3. Undo the most recent 'n' transactions",
                "4. Turn off the ATM",
                "5. Set the date",
                "6. View product and transferable account requests",
                "7. Log out"};
        int input = 0;
        String choice;
        while(input != 7){

            choice = (String)JOptionPane.showInputDialog(null,
                    "Welcome, " + bankWorker.getUsername() + ". ", "Manager menu",
                    JOptionPane.QUESTION_MESSAGE, icon, choices, "Choose One");
            input = Integer.parseInt(choice.replaceAll("[\\D]",""));
            switch (input) {
                case 1:
                    viewControlCreateClientAccount();
                    break;
                case 2:
                    bankWorker.restockBankMachine();
                    break;
                case 3:
                    viewControlUndoTransactions();

                    /*for (Client client : clients) {
                        if (client.getUsername().equals(userWantsToUndo)) {
                            //try {
                                bm.undoLastTransaction(client, account);
                            } catch (OverdraftLimitException e) {
                                JOptionPane.showMessageDialog(null, "Transaction cannot be " +
                                        "undo because the other client's account does not have enough money.");
                            } catch (TransferOutDeniedException e) {
                                JOptionPane.showMessageDialog(null, "Transaction cannot be " +
                                        "undo because the other client's account cannot transfer out money.");
                            }
                        }
                    }*/
                    break;
                case 4:
                    JOptionPane.showMessageDialog(null, "Exiting system", "ATM", JOptionPane.QUESTION_MESSAGE, icon);
                    return true;
                case 5:
                    viewControlSetDate();
                    break;
                case 6:
                    super.viewControlCreateAccount();
                    break;
                case 7:
                    JOptionPane.showMessageDialog(null, "Returning to main menu", "ATM", JOptionPane.QUESTION_MESSAGE, icon);
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Sorry, that wasn't an option, please" +
                            " try again", "ATM", JOptionPane.QUESTION_MESSAGE, icon);
                    break;
            }
        }
        return false;
    }

    private void viewControlUndoTransactions(){
        String userWantsToUndo = JOptionPane.showInputDialog(null,"Enter the username of the user who asked " +
                "for undo transactions");
        int account = Integer.parseInt(JOptionPane.showInputDialog("Enter the account number of that " +
                "user for the account whose last transaction he/she wants to undo"));
        int n = Integer.parseInt(JOptionPane.showInputDialog("Enter the amount of transactions you wish to attempt to undo"));
        Client client = userManager.getClient(userWantsToUndo);
        String data = client.getRecentTransactionsUnformatted(account, n);
        String[] lines = data.split("\n"); //Put each line of the data in array lines.
        int lineNum = 0;
        while (lineNum < lines.length && n > 0) { //While there are still lines in the data you are reading or you haven't undone n amount of transactions.
            String[] tranData = lines[lineNum].split(", ");
            double amount = Double.valueOf(tranData[3]);
            String toId = tranData[2];
            String information = tranData[5];
            if (userManager.isValidUsername("client", toId)) {
                Client otherClient = userManager.getClient(toId);
                if (information.equals("withdraw]")) {
                    new TransferManager().transferToUser(client, otherClient, amount, "Undone transaction");
                    n--;
                } else if (information.equals("deposit]")) {
                    new TransferManager().transferToUser(otherClient, client, amount, "Undone transaction");
                    n--;
                }
                                /*
                            } catch (OverdraftLimitException e) {
                                JOptionPane.showMessageDialog(null, "Transaction cannot be " +
                                        "undone because the other client's account does not have enough money.");
                            } catch (TransferOutDeniedException e) {
                                JOptionPane.showMessageDialog(null, "Transaction cannot be " +
                                        "undone because the other client's account cannot transfer out money.");
                            } catch (NoSuchAccountException e) {
                                JOptionPane.showMessageDialog(null, "No such account exists.");
                            }
                            */
            }
            lineNum++;
        }
    }


    private void viewControlSetDate(){
        boolean noDay = true;
        int day = 0; // 0 is a placeholder value
        int month = 0; // 0 is a placeholder value
        int year = 0; // 0 is a placeholder value

        while(noDay){
            String userInput = JOptionPane.showInputDialog("Current date: " + date + "\nPlease enter the day or 'x' to go back. Valid values: 1-30");
            if(userInput.equals("x")){
                noDay = false;
            }
            else{
                try{
                    day = Integer.parseInt(userInput);

                    boolean noMonth = true;
                    while(noMonth){
                        userInput = JOptionPane.showInputDialog("Please enter the month or 'x' to go back. Valid values: 1-12");
                        if(userInput.equals("x")){
                            noMonth = noDay = false;
                        }
                        else{
                            try{
                                month = Integer.parseInt(userInput);

                                boolean noYear = true;
                                while(noYear){
                                    userInput = JOptionPane.showInputDialog("Please enter the year or 'x' to go back.");
                                    if(userInput.equals("x")){
                                        noYear = noMonth = false;
                                    }
                                    else{
                                        try{
                                            year = Integer.parseInt(userInput);
                                            noYear = noMonth = noDay = false;

                                        }
                                        catch(NumberFormatException e){
                                            viewControlInvalidInput();
                                        }

                                    }
                                }
                            }
                            catch(NumberFormatException e){
                                viewControlInvalidInput();
                            }
                        }
                    }

                } catch (NumberFormatException e) {
                    viewControlInvalidInput();
                }
            }

        }

        if (year != 0){
            DateManager newDate = new DateManager(day, month, year);
            centralControl.setFirstTimeSettingDate(true);
            centralControl.setDate(newDate);
            JOptionPane.showMessageDialog(null, "Successfully set the date.\n" +
                    "Please shut off the ATM and turn it back on in order for the date to officially reset."
                    , "ATM", JOptionPane.QUESTION_MESSAGE, icon);
        }

    }

    /**
     * View & control invalid input pop-up.
     */
    private void viewControlInvalidInput(){
        JFrame frame = new JFrame();
        JOptionPane.showMessageDialog(frame,
                "Invalid input. Please enter an option specified in the panel.",
                "Invalid input",
                JOptionPane.WARNING_MESSAGE, icon);
    }



    private void viewControlCreateClientAccount() {
        String username = JOptionPane.showInputDialog("Enter the new clients username");
        if (!userManager.isValidUsername("client", username)) {
            String choices[] = {"Chequing Account", "Credit Card Account", "Line of Credit Account",
                    "Savings Account", "No Account"};

            String accountType = (String)JOptionPane.showInputDialog(null,
                    "Please select a default account type:", "User creation",
                    JOptionPane.QUESTION_MESSAGE, icon, choices, "Choose One");
            accountType = accountType.toLowerCase();

            Client newClient = bankWorker.createUserAccount(username);

            TransferableAccount newAccount;
            if(!accountType.equals("no account")){
                newAccount = bankWorker.createAccount(accountType, date, CurrencyType.CAD);
                newClient.addTransferableAccount(newAccount);
                if (newAccount instanceof ChequingAccount){
                    newClient.setPrimary((ChequingAccount) newAccount);
                }
                else{
                    ChequingAccount automaticChequingAccount = (ChequingAccount) bankWorker.createAccount("chequing account", date, CurrencyType.CAD);
                    newClient.setPrimary(automaticChequingAccount);
                    newClient.addTransferableAccount(automaticChequingAccount);
                    viewControlAutomaticChequingCreation();
                }
            }
            else{
                ChequingAccount automaticChequingAccount = (ChequingAccount) bankWorker.createAccount("chequing account", date, CurrencyType.CAD);
                newClient.setPrimary(automaticChequingAccount);
                newClient.addTransferableAccount(automaticChequingAccount);
                viewControlAutomaticChequingCreation();
            }

            userManager.addClient(newClient);
        } else {
            JOptionPane.showMessageDialog(null, "That user already exists.", "ATM", JOptionPane.QUESTION_MESSAGE, icon);
        }

        /*
        try {
            if (!userManager.isValidUsername("client", username)) {
                String choices[] = {"Chequing Account", "Credit Card Account", "Line of Credit Account",
                        "Savings Account", "Mortgage Account", "GIC Account", "No Account"};

                String accountType = (String)JOptionPane.showInputDialog(null,
                        "Please select the default account type.", "User menu",
                        JOptionPane.QUESTION_MESSAGE, null, choices, "Choose One");
                accountType = accountType.toLowerCase();

                Client newClient = bankWorker.createUserAccount(username);

                TransferableAccount newAccount;
                if(!accountType.equals("no account")){
                    newAccount = bankWorker.createAccount(accountType, date, CurrencyType.CAD);
                }
                else{
                    newAccount = bankWorker.createAccount("chequing account", date, CurrencyType.CAD);
                }

                newClient.addTransferableAccount(newAccount);
                userManager.addClient(newClient);
            }
        } catch (UserNameNotMatchException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null,
                    "Sorry, username doesn't match, " +
                            "please input at least 4 digits and compose with numbers, letters, - and _");
        }
         */

    }

    private void viewControlAutomaticChequingCreation(){
        JFrame frame = new JFrame();
        JOptionPane.showMessageDialog(frame, "A primary chequing account for the client was automatically created.\n" +
                "This feature exist since all transfers and deposits are made to the primary chequing account.\n" +
                "This benefits the client since they can now make deposits and transfers without having to first create " +
                "a chequing account.","Automatic chequing account created", JOptionPane.QUESTION_MESSAGE, icon);
    }



}
