package banksys.filehandler;

import banksys.currency.CurrencyType;

import java.io.File;

public class CurrencyFileOperator extends FileOperator<CurrencyData>{

    public static String FILE_PATH = "phase2"
            + File.separator + "Project"
            + File.separator + "src"
            + File.separator + "banksys"
            + File.separator + "txtfile"
            + File.separator + "currency";

    public CurrencyFileOperator(File f) {
        super(f);
    }

    @Override
    public void insertDataLine(Data data, int lineNum) {
        this.loadAllData();
        this.dataSet.add(lineNum, (CurrencyData) data);
        String[] allData = new String[this.dataSetLength()];
        for (int i = 0; i < dataSetLength(); i++){
            allData[i] = this.dataSet.get(i).toString();
        }
        this.writeLines(allData, false);
    }

    @Override
    void addData(String[] data) {
        CurrencyData currencyData = CurrencyData.parse(data);
        if (currencyData != null) {
            this.dataSet.add(currencyData);
        }
    }

    public double findCurrency(CurrencyType currencyFrom, CurrencyType currencyTo){
        this.loadAllData();
        for (CurrencyData currencyData : dataSet) {
            if (currencyData.getFromCurrency().equals(currencyFrom)
                    && currencyData.getToCurrency().equals(currencyTo)) {
                return currencyData.getCurrency();
            }
        }
        return -1.00;
    }

}
