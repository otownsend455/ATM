package banksys.filehandler;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Abstract file operators provided basic methods to read and write file and for child class to implement.
 * @param <T> Any dataType that should be implemented. Should make a enum class for dateTypes in Phase2.
 */
public abstract class FileOperator<T> implements Serializable {
    File f;
    List<T> dataSet;
    BufferedReader br;
    BufferedWriter bw;

    /**
     * a abstract constructor that will initialize the data set and file.
     * @param f an input file that is needed to be operated
     */
    public FileOperator(File f){
        this.f = f;
        this.dataSet = new ArrayList<>();
    }

    /**
     * a public method that write data into f after parsing to String, shared by all subclasses
     * @param data the Certain data that is T in the certain operator class.
     */
    public void writeData(T data) {
        this.writeLine(data.toString(), true);
    }

    /**
     * write a line using message provided
     * @param message message provided
     * @param append append the file or overwrite
     */
    public void writeLine(String message, boolean append) {
        try {
            bw = new BufferedWriter(new FileWriter(f, append));
            bw.write(message);
            bw.newLine();
        } catch (IOException e){
            e.printStackTrace();
        } finally {
            if (bw != null) {
                try {
                    bw.flush();
                    bw.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * write an string array to the file, each element a line in the file
     * @param messages as above
     * @param append as above
     */
    public void writeLines(String[] messages, boolean append){
        try {
            bw = new BufferedWriter(new FileWriter(f, append));
            for (String message : messages) {
                bw.write(message);
                bw.newLine();
            }
        } catch (IOException e){
            e.printStackTrace();
        } finally {
            if (bw != null) {
                try {
                    bw.flush();
                    bw.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * load all data into dataSet, arranged by the lines of reading.
     */
    public void loadAllData(){
        this.dataSet.clear();
        try {
            String line;
            this.br = new BufferedReader(new FileReader(this.f));
            while((line = this.br.readLine()) != null){
                this.addData(line.split(","));
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (this.br != null) {
                try {
                    this.br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * load data from target line to target line
     * @param startLine start line
     * @param endLine end line
     */
    public void loadTargetLineOfData(int startLine, int endLine){
        this.dataSet.clear();
        try {
            LineNumberReader lnr = new LineNumberReader(new FileReader(f));
            lnr.setLineNumber(0);
            for (String cLine; (cLine = lnr.readLine()) != null;) {
                System.out.println("line number:" + lnr.getLineNumber());
                if (lnr.getLineNumber() >= startLine && lnr.getLineNumber() <= endLine){
                    this.addData(cLine.split(","));
                }
            }
            lnr.close();
        } catch (IOException e){
            e.printStackTrace();
        }
    }

    /**
     * make the file empty
     */
    public void clearFile() {
        try {
            bw = new BufferedWriter(new FileWriter(f, false));
            bw.write("");
        } catch (IOException e){
            e.printStackTrace();
        } finally {
            if (bw != null) {
                try {
                    bw.flush();
                    bw.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * insert data at a certain line
     * @param data certain data type
     * @param lineNum
     */
    public abstract void insertDataLine(Data data, int lineNum);

    /**
     * add a string list of data and is available for certain data to parse
     * @param data
     */
    abstract void addData(String[] data);

    /**
     * load certain data at certain index in data set
     * @param index
     * @return
     */
    public T loadData(int index){
        return dataSet.get(index);
    }

    /**
     * get data length. separate data set from direct operations because it is more safe and make sure the data in data set is pure.
     * @return
     */
    public int dataSetLength(){
        return this.dataSet.size();
    }

}
