package banksys.filehandler;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Base64;

public class SerializableObjectData extends Data implements Serializable {
    private String objectClass;
    private Object storingObject;

    public SerializableObjectData(Object obj) {
        this.objectClass = obj.getClass().getName();
        this.storingObject = obj;
    }

    public Object getStoringObject() {
        return storingObject;
    }

    public String getObjectClass() {
        return objectClass;
    }

    @Override
    String[] toStringList() {
        return new String[]{this.getDataId(), this.objectClass};
    }

    @Override
    public String toString() {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        try {
            ObjectOutputStream so = new ObjectOutputStream(bo);
            so.writeObject(this);
            so.flush();

        } catch (IOException e) {
            e.printStackTrace();
        }
        return Base64.getEncoder().encodeToString(bo.toByteArray());
    }
}
