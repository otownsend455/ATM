package banksys.filehandler;

import java.io.File;
import java.io.IOException;

/**
 * a file creator class that will divide the name and path. will raise exception if file already exists.
 */
public class FileCreator {
    private File dir;
    private File f;

    public FileCreator(String filePath){
        String path = filePath.substring(0, filePath.lastIndexOf(File.separator));
        String name = filePath.substring(filePath.lastIndexOf(File.separator) + 1, filePath.length());
        this.dir = new File(path);
        this.f = new File(filePath);
    }

    public boolean exists(){
        return f.exists();
    }

    public boolean createFile(){
        if (!this.dir.mkdirs()){
            //log part, normal warning.
        }
        try {
            return f.createNewFile();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }
}
