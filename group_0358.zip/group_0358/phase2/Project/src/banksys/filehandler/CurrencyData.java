package banksys.filehandler;

import banksys.currency.CurrencyType;

/**
 * A DataType for Currency,
 * Stores the type of 2 currencies and the value of the currency
 */
public class CurrencyData extends Data {
    private CurrencyType fromCurrency;
    private CurrencyType toCurrency;
    private double currency;

    /**
     * Currency constructor for newly created currency data.
     * @param fromCurrency the currency is pending to change
     * @param toCurrency the target currency
     * @param currency the currency value between these 2 types.
     */
    public CurrencyData(CurrencyType fromCurrency, CurrencyType toCurrency, double currency){
        super();
        this.fromCurrency = fromCurrency;
        this.toCurrency = toCurrency;
        this.currency = currency;
    }

    /**
     * Currency constructor for data read from files.
     * @param dataId the former dataId
     * @param fromCurrency the currency is pending to change
     * @param toCurrency the target currency
     * @param currency the currency value between these 2 type.
     */
    CurrencyData(String dataId, CurrencyType fromCurrency, CurrencyType toCurrency, double currency){
        super(dataId);
        this.fromCurrency = fromCurrency;
        this.toCurrency = toCurrency;
        this.currency = currency;
    }

    public CurrencyType getFromCurrency() {
        return fromCurrency;
    }

    public CurrencyType getToCurrency() {
        return toCurrency;
    }

    public double getCurrency() {
        return currency;
    }

    /**
     * return a list contains important information of currency data.
     * @return return a list contains:
     * 0. dataId,
     * 1. Abbreviation String of fromCurrency
     * 2. Abbreviation String of toCurrency
     * 3. The ratio of currency
     */
    @Override
    String[] toStringList() {
        return new String[]{this.getDataId(),
                this.fromCurrency.toString(),
                this.toCurrency.toString(),
                String.valueOf(this.currency)};
    }

    /**
     * This method parse a certain string list of data into Currency data object,
     * the same structure as the to String list.
     * @param data a data list consist of strings
     * @return return a newly created data object
     */
    static CurrencyData parse(String[] data){
        CurrencyType currencyFrom = null;
        CurrencyType currencyTo = null;
        if (data.length == 3) {
            for (CurrencyType currencyType: CurrencyType.values()){
                if (currencyType.toString().equals(data[0])){
                    currencyFrom = currencyType;
                }
                if (currencyType.toString().equals(data[1])){
                    currencyTo = currencyType;
                }
            }
            if (currencyFrom == null || currencyTo == null){
                return null;
            }
            return new CurrencyData(currencyFrom,
                    currencyTo,
                    Double.valueOf(data[2]));
        }else if (data.length == 4){
            for (CurrencyType currencyType: CurrencyType.values()){
                if (currencyType.toString().equals(data[1])){
                    currencyFrom = currencyType;
                }
                if (currencyType.toString().equals(data[2])){
                    currencyTo = currencyType;
                }
            }
            if (currencyFrom == null || currencyTo == null){
                return null;
            }
            return new CurrencyData(data[0],
                    currencyFrom,
                    currencyTo,
                    Double.valueOf(data[3]));
        }
        return null;
    }

    /**
     * How data is stored in the text files.
     * @return return a data string after regulation.
     */
    @Override
    public String toString() {
        return this.getDataId() + "," + fromCurrency.toString() + "," + toCurrency.toString() + "," + currency;
    }
}
