package banksys.currency;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

/**
 * http://data.fixer.io/api/END_POINT?access_key=API_KEY should be the default api access Url
 * 1b9cab8aacb2cbe5f46f74582198d808 is my private access Key which applied from fixer website
 */

/**
 * only works for today, yesterday. the day before yesterday right now, since more url changes should be added based on the endpoint
 * more exceptions are expected on internet connection io exception.
 */
public class CurrencyOperator {
    private String END_POINT;
    private final String API_KEY = "1b9cab8aacb2cbe5f46f74582198d808";
    private final String API_Url = "http://data.fixer.io/api/END_POINT?access_key=API_KEY";
    private APIHandler apiHandler;
    private Map<CurrencyType, Double> currencyValues = new HashMap<>();

    /**
     * by default, the url will return a currency json based on EUR.
     * @param endPoint
     */
    @SuppressWarnings("unchecked")
    public CurrencyOperator(EndPoint endPoint){
        String url = this.API_Url
                .replace("END_POINT", endPoint.toString())
                .replace("API_KEY", this.API_KEY);
        try {
            this.apiHandler = new APIHandler();
            currencyValues = apiHandler.getCurrencyValues(apiHandler.getJsonFromUrl(url));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     *  we did not pay for this API so we cannot use currency besides EUR. Since we should use Currency Calculator.
     * @param endPoint
     * @param currencyType
     */
    @Deprecated
    @SuppressWarnings("unchecked")
    public CurrencyOperator(EndPoint endPoint, CurrencyType currencyType){
        String url = this.API_Url
                .replace("END_POINT", endPoint.toString())
                .replace("API_KEY", this.API_KEY)
                + "&base="
                + currencyType.toString();
        try {
            this.apiHandler = new APIHandler();
            String result = apiHandler.getJsonFromUrl(url);
            currencyValues = apiHandler.getCurrencyValues(result);
            System.out.println(result);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * get currency between two types of currency.
     * @param currencyType1 from currency type
     * @param currencyType2 to currency type
     * @return ratio
     */
    public double getCurrency(CurrencyType currencyType1, CurrencyType currencyType2){
        if (currencyType1.equals(currencyType2)){
            return 1;
        } else if (currencyType1.equals(CurrencyType.EUR)){
            return this.currencyValues.get(currencyType2) / 1;
        } else if (currencyType2.equals(CurrencyType.EUR)){
            return 1 / this.currencyValues.get(currencyType1);
        } else {
            return this.currencyValues.get(currencyType2) / this.currencyValues.get(currencyType1);
        }
    }


    /**
     * enum class for the Endpoint in Url building.
     */
    public enum EndPoint{
        LATEST("latest"),
        TODAY("today"),
        YESTERDAY("yesterday"),
        DAY_BEFORE_YESTERDAY("day before yesterday"),
        TIMESERIES("timeseries");

        private String date;

        EndPoint(String point){
            if (point.equals("timeseries")){
                this.date = "timeseries";
                return;
            } else if (point.equals("latest")){
                this.date = point;
                return;
            }
            Calendar cal = Calendar.getInstance();
            if (point.equals("yesterday")){
                cal.add(Calendar.DATE, -1);
            } else if (point.equals("day before yesterday")){
                cal.add(Calendar.DATE, -2);
            }
            this.date = new SimpleDateFormat( "yyyy-MM-dd").format(cal.getTime());
        }

        @Override
        public String toString() {
            return this.date;
        }
    }
}
